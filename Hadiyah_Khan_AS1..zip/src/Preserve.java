import java.util.InputMismatchException;
import java.util.Scanner;
/**
 * CET - CS Academic Level 3
 * This class extends FoodItem to add use its methods nad add to them 
 * Student Name: hadiyah Khan
 * Student Number:  041049366
 * Course: CST8130 - Data Structures
 * @author/Professor: James Mwangi PhD. 
 * 
  */
public class Preserve extends FoodItem {
	/**
	 * private variable itn jarSize
	 */
	private int jarSize;

	/**
	 * class preserve contructoor for initializing jarzize
	 */
	public Preserve() {
		super();
		this.jarSize = 0;
	}

	/**
	 * // adds the jar size to the to string
	 */
	public String toString() {
		return super.toString() + "\n size in mL : " + this.jarSize;
	}

	/**
	 * asks the name for the jar size
	 */
	public boolean addItem(Scanner scanner) {
		if (!super.addItem(scanner)) { // if preserve is not choses, this piece of code returns false and deosnt print
			// anything
			return false;
		}

		try {

			System.out.println("Enter the size of the jar in millilitres: "); // enter the jar size
			this.jarSize = scanner.nextInt();

			if (this.jarSize <= 0) {
				System.out.println(" invalid input: input positive numbers"); // erorr to not enter negative numbers or
				// input 0
			}
		} catch (InputMismatchException e) {
			System.out.println("invalid input: enter numerical input"); // error for wrong input, only input positive
			// numbers
			scanner.nextInt();
			scanner.nextLine();
		}
		return true;
	}

}
