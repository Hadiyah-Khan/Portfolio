import java.util.InputMismatchException;
import java.util.Scanner;
/**
 * CET - CS Academic Level 3
 * This class contains the menue for assingment1 
 * Student Name: hadiyah Khan
 * Student Number:  041049366
 * Course: CST8130 - Data Structures
 * @author/Professor: James Mwangi PhD. 
 * 
  */
public class Assign1 {
	/**
	 * private vairable for option 1 for the switch case
	 */
	private final static int CHOICE_1 = 1;
	/**
	 * private vairable for option 2 for the switch case
	 */
	private final static int CHOICE_2 = 2;
	/**
	 * private vairable for option 3 for the switch case
	 */
	private final static int CHOICE_3 = 3;
	/**
	 * private vairable for option 4 for the switch case
	 */
	private final static int CHOICE_4 = 4;
	/**
	 * private vairable for option 5 for the switch case
	 */
	private final static int CHOICE_5 = 5;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/**
		 * new Scanner object input
		 */
		Scanner input = new Scanner(System.in);
		/**
		 * new obect of the inventory class called i
		 */
		Inventory i = new Inventory();

		/**
		 * int variable that will be used in in the user input
		 */
		int choice;
		/**
		 * boolean value for error
		 */
		boolean error = false;

		do {

			error = false;

			try {
				do {
					displauMenu(); // method displayMenu is called
					choice = input.nextInt();

					switch (choice) { // case switch is used to call methods form inventory that correspond to the
					// diffrent choices
					case CHOICE_1:
						i.addItem(input); // option 1, add items to inventory
						break;

					case CHOICE_2:
						System.out.println(i.toString()); // option 2, print out everything inside the inventory

						break;

					case CHOICE_3:
						i.updateQuantity(input, true); // option 3 to call the method to buy an item
						break;

					case CHOICE_4:
						i.updateQuantity(input, false); // option 4 to call the method to sell an item
						break;
					case CHOICE_5:
						System.out.println("exitng"); // option to exit the program
						System.out.println(".");
						System.out.println(".");
						System.out.println(".");
						System.out.println(".");
						System.out.println(".");
						System.out.println(".");
						System.out.println(".");

					default:
						System.out.println("invalid input valid integers, try again: valid input: [1,2,3,4,5]  "); // the
						// error
						// for
						// the
						// wrong
						// input
						// in
						// numebrs

					}

				} while (choice != 5); // turn the loop until user inputs 5 to exit the program

			} catch (InputMismatchException e) {

				System.out.println(" Please input valid integers, try again: valid ineteger number: (1,2,3,4,5) "); // the
				// error
				// for
				// the
				// wrong
				// input
				// in
				// letters
				error = true;
				input.nextLine();
			}
		} while (error);

		// close the scanner
		input.close();
	}

	/**
	 * method that has the meneu options
	 */
	public static void displauMenu() {

		System.out.println("--------------------------------meneu--------------------------");
		System.out.println(CHOICE_1 + ": Add Item to Inventory");
		System.out.println(CHOICE_2 + ": Display Current Inventory");
		System.out.println(CHOICE_3 + ": Buy Item(s)");
		System.out.println(CHOICE_4 + ": Sell Item(s)");
		System.out.println(CHOICE_5 + ": To Exit");

		System.out.println("enter intput: ");

	}

}
