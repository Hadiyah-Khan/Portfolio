import java.util.InputMismatchException;
import java.util.Scanner;
/**
 * CET - CS Academic Level 3
 * This class extends FoodItem to add use its methods nad add to them 
 * Student Name: hadiyah Khan
 * Student Number:  041049366
 * Course: CST8130 - Data Structures
 * @author/Professor: James Mwangi PhD. 
 * 
  */
public class Fruit extends FoodItem {
	/**
	 * private string variable for orchard name
	 */
	private String orchardName;

	/**
	 * class fruit constructor for initializing orchard name
	 */
	public Fruit() {
		super();
		this.orchardName = "";
	}

	/**
	 * // adds orchard name to the toStirng
	 */
	public String toString() {

		return super.toString() + "\n Orchard supplier : " + this.orchardName;
	}

	/**
	 * to add the orchard name
	 */
	public boolean addItem(Scanner input) {

		if (!super.addItem(input)) { // if fruit is not choses, this piece of code returns false and deosnt print
			// anything
			return false;
		}
		try {
			System.out.println("Enter the name of the orchard supplier: "); // enter orchard name
			this.orchardName = input.next();
		} catch (InputMismatchException e) { // wrong input error
			System.out.println("invalid input: enter characters");
			input.nextLine();
		}
		return true;
	}

}
