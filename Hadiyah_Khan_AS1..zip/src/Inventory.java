import java.util.InputMismatchException;
import java.util.Scanner;
/**
 * CET - CS Academic Level 3
 * This class has methods to be called upon by the main class  
 * Student Name: hadiyah Khan
 * Student Number:  041049366
 * Course: CST8130 - Data Structures
 * @author/Professor: James Mwangi PhD. 
 * 
  */
public class Inventory {
	/**
	 * SENTINAL is -1, if index returns -1 , it will return SENTINAL , which means item
	 * does not exist;
	 */
	private static final int SENTINAL = -1;
	/**
	 * string variabel f for fruit in the switch case
	 */
	private static final String CHOICE_1 = "f";
	/**
	 * string variable v for vegetable for switch case
	 */
	private static final String CHOICE_2 = "v";
	/**
	 * string variable p for pereserve for switch case
	 */
	private static final String CHOICE_3 = "p";

	/**
	 * 
	 */
	private static final String CHOICE_4 = "b";
	/**
	 * array of fooodItem called inventory
	 */
	private FoodItem[] inventory;
	/**
	 * private integer numItems _ numItems is the number of items in inventory
	 */
	private int numItems;
/**
 * 
 */
private int newCode;	
	
	/**
	 * class contructor for inventory makes the array inventory to size 20
	 */
	public Inventory() {
		this.inventory = new FoodItem[20]; // make array size 20

		this.numItems = 0; // initialize numitems;

	}

	/**
	 * print out the toStirng
	 */
	public String toString() {

		String s = "";
		for (int i = 0; i < this.numItems; i++) {
			s += this.inventory[i].toString() + "\n";
		}

		return s;

	}

	/**
	 * 
	 * @param item represents the item in array/inventory
	 * @return SENTINAL if the item does not exist
	 */
	public int alreadyExists(FoodItem item) {

		for (int i = 0; i < this.numItems; i++) {
			if (this.inventory[i].isEqual(item)) {
				return i; /// if item is found in inventory, return item
			}

		}
		return SENTINAL; // return sentinal (-1) when item is not found

	}

	/**
	 * adds item into the array
	 * 
	 * @param scanner is an object of Scanner
	 * @return true
	 */
	public boolean addItem(Scanner scanner) {
		Scanner input = new Scanner(System.in);
		if (this.numItems == 20) {
			System.out.println(" Inventory is full. no more items can be added"); // if array is full. no more items can
			// be added
			return false;
		}

		FoodItem item = null; // initialsie item to null

		System.out.println("--------------------------------meneu_2--------------------------"); // menue 2 to add
		// fruit,
		// vegtitable,
		// priservve or to
		// exit the program
		System.out.println("do you with to add a fruit (" + CHOICE_1 + ")");
		System.out.println("do you with to add a vegetable (" + CHOICE_2 + ")");
		System.out.println("do you with to add a preserve (" + CHOICE_3 + ")");
		System.out.println(" do you wish to add a bread (" + CHOICE_4 + ")");
		System.out.println(" please enter (f) , (v) , (p) , (b)");
		/**
		 * string choices - user inputs string value
		 */
		String choices;

		choices = input.nextLine();

		boolean error = false;

		do {

			error = false;
			try {
			
					switch (choices) {
					case CHOICE_1: // fruits is chosen
						item = new Fruit();
						break;

					case CHOICE_2: // vegetable is chosen
						item = new Vegetable();
						break;

					case CHOICE_3: // preserve is chosen
						item = new Preserve();
						break;
					case CHOICE_4: 
						item = new Bread();
						break;
					default:
						System.out.println("Please input valid characters try again: valid input (f) (v) (p) (b) "); // incorrect
						scanner.nextLine();
						// value
						// was
						// entered.
						return false;
					}

				
			} catch (InputMismatchException e) {
				// the error for the wrong input in letters
				System.out.println(" Please input valid characters try again: valid input (f) (v) (p) ");

				scanner.nextLine();
			}
		} while (error);

		if (!item.addItem(scanner)) { // if option 1 is not chosen, return false, nothign prints
			return false;
		}

		int index = alreadyExists(item);
		if (index == SENTINAL) {
			this.inventory[this.numItems] = item;
			this.numItems++;
		} else {
			this.inventory[index].updateItem(item.getItemQuantityInStock());

		}

		return true;

	}

	public boolean updateQuantity(Scanner scanner, boolean buyOrSell) {

		FoodItem item = new FoodItem(); // a new object of the class FoodItem called item;
		int quantity = 0; // int variable for quantity (quantity of items) initialised to 0;

		if (!item.inputCode(scanner)) { 
			
		return false;
		}
		
		int index = alreadyExists(item);
		
	
		
		

		if (index == SENTINAL) { // if index equals SENTINAL (-1) then the item is not found;
			System.out.println("Item not found!");
			return false;
		}
		
		try {
			
			if (index != SENTINAL) {
				String buySell = buyOrSell ? "buy" : "sell"; // string buySell equals the boolean parameter buyOrSell
				// which are strings buy (true) or sell (false);
				System.out.print("Enter valid quantity to " + buySell + ": ");
				if (scanner.hasNextInt()) {
					int amount = scanner.nextInt();
					if (amount > 0) { // if amount of items is greater then 0, then user is allowed to buy or sell the
						// item
						int newAmount = buyOrSell ? amount : amount * -1; // item is subtracted
						inventory[index].updateItem(newAmount); // inventory is updated with the new amount after the
						// items in the inventory are subtracted
						if (!this.inventory[index].updateItem(newAmount)) {
							System.out.println("Not enough items in stock!"); // if inventory does not have enough
							// items, print out message
							return false;
						}
						return true;

					} else {
						System.out.println("Invalid quantity..."); // wrong input error
					}
				} else {
					System.out.println("Invalid quantity..."); // wrong input error
				}
			}
			return false;
			
			
		} catch (InputMismatchException e) {
			System.out.println(" invalid entry......"); // wrong input error
			scanner.nextLine();
		}
		return false;

	}

}
