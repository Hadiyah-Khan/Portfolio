import java.util.HashSet;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.Set;

/**
 * CET - CS Academic Level 3
 * This class contians methods to be used by inventory nad setters and getters 
 * Student Name: hadiyah Khan
 * Student Number:  041049366
 * Course: CST8130 - Data Structures
 * @author/Professor: James Mwangi PhD. 
 * 
  */
public class FoodItem {
	/**
	 * private integer itemCode - item code code item
	 */
	private int itemCode;
	/**
	 * private string for item name
	 */
	private String itemName;
	/**
	 * private float value for the price of the item
	 */
	private float itemPrice;
	/**
	 * private integer for the quanitiy of item in stock
	 */
	private int itemQuantityInStock;
	/**
	 * private float value for item cost
	 */
	private float itemCost;

	/**
	 * class contructor FoodItem, initialize the variables
	 */
	public FoodItem() {

		this.setItemCode(0);

		this.itemName = "";

		this.itemPrice = 0.00f;

		this.itemQuantityInStock = 0;

		this.itemCost = 0.00f;

	}

	/**
	 * to stirng to return the items in inventory
	 */
	public String toString() {

		return "item Code :" + this.getItemCode() + "\n Item Name: " + this.itemName + " \n Item Price: "
				+ this.itemPrice + " \n Item Quantity In Stock: " + this.itemQuantityInStock + "\n Item Cost "
				+ this.itemCost;

	}

	/**
	 * method to update quantity of items in stock method to
	 * @param amount of items
	 * @return true or false
	 *         items
	 */
	public boolean updateItem(int amount) {

		if (this.itemQuantityInStock + amount < 0) { // if amount is less then- return false
			return false;
		}

		this.itemQuantityInStock += amount;
		return true;

	}

	/**
	 *  method to see if item is equal to the code of item
	 * @param item variabel of FoodItem
	 * @return the itemcode of item 
	 *         
	 */
	public boolean isEqual(FoodItem item) {
		return this.getItemCode() == item.getItemCode();

	}

	/**
	 * method to ask user for input for items
	 * @param scanner obejct of Scanner
	 * @return true if there are items to enter method to add items
	 */
	public boolean addItem(Scanner scanner) {
		
			
		Set<Integer> usedCodes = new HashSet<>();
		System.out.println("Enter the code for the item: ");
		while (true) {
		  try {
		    int inputCode = scanner.nextInt();
		    scanner.nextLine();
		    
		    
		    if (usedCodes.contains(inputCode)) {
		      System.out.println("Code already used. Enter a different code: ");
		    } else {
		      usedCodes.add(inputCode);
		      this.setItemCode(inputCode);
		      break;
		    }
		  } catch (InputMismatchException e) {
		    System.out.println("Invalid input. Enter a number for the code: ");
		    scanner.nextLine();
		  }
		}

		
		System.out.println("Enter the name for the item: ");
		try {
		this.itemName = scanner.next();
		}catch (InputMismatchException e) {
			  System.out.println("Invalid input. Enter a string for the item name: ");
			  scanner.nextInt();
			  scanner.nextLine();
			  return false;
			}
		
		System.out.println("Enter quantity for the item: ");
		try {
		  this.itemQuantityInStock = scanner.nextInt();
		  if (itemQuantityInStock <= 0) {
			  System.out.println(" input cannot be negative");
			  scanner.nextInt();
			  scanner.nextLine();
		  }
		} catch (InputMismatchException e) {
		  System.out.println("Invalid input. Enter a number for the quantity: ");
		  scanner.nextInt();
		  scanner.nextLine();
		  
		  return false;
		}

		System.out.println("Enter the cost of the item: ");
		try {
		  this.itemCost = scanner.nextFloat();
		  if (itemCost <= 0) {
			  System.out.println(" input cannot be negative");
			  scanner.nextFloat();
			  scanner.nextLine();
		  }
		} catch (InputMismatchException e) {
		  System.out.println("Invalid input. Enter a number for the cost: ");
		  scanner.nextInt();
		  scanner.nextLine();
		  return false;
		}

		System.out.println("Enter the sales price of the item: ");
		try {
		  this.itemPrice = scanner.nextFloat();
		  if ( itemPrice <= 0) {
			  System.out.println("input cannot be negative");
			  scanner.nextFloat();
			  scanner.nextLine();
		  }
		} catch (InputMismatchException e) {
		  System.out.println("Invalid input. Enter a number for the sales price: ");
		  scanner.nextLine();
		  return false;
		}

		return true;
	}

	/**
	 * this method is to setinput code to the  number the user entered
	 * @param scanner obect of Scanner
	 * @return true mehthod to enter code for item
	 */
	public boolean inputCode(Scanner scanner) {

		System.out.println("Enter code for the item: ");
		
		this.setItemCode(scanner.nextInt());

		
		
		return true;

	}

	/**
	 * 
	 * 
	 * getter for itemcode
	 * 
	 * @return itemcode
	 */
	public int getItemCode() {
		return itemCode;
	}

	/**
	 * setter for itemCode
	 * 
	 * @param itemCode
	 */
	public void setItemCode(int itemCode) {
		this.itemCode = itemCode;
	}

	/**
	 * getter itemname
	 * 
	 * @return itemname
	 */
	public String getItemName() {
		return itemName;
	}

	/**
	 * setter for itemName
	 * 
	 * @param itemName
	 */
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	/**
	 * getter for itemPrice
	 * 
	 * @return itemPrice
	 */
	public float getItemPrice() {
		return itemPrice;
	}

	/**
	 * setter for itemPrice
	 * 
	 * @param itemPrice
	 */
	public void setItemPrice(float itemPrice) {
		this.itemPrice = itemPrice;
	}

	/**
	 * getter for quantity of item in stck
	 * 
	 * @return itemQuantityInStock
	 */
	public int getItemQuantityInStock() {
		return itemQuantityInStock;
	}

	/**
	 * setter for itemQuantityInStock
	 * 
	 * @param itemQuantityInStock
	 */
	public void setItemQuantityInStock(int itemQuantityInStock) {
		this.itemQuantityInStock = itemQuantityInStock;
	}

	/**
	 * getter for item cost
	 * 
	 * @return itemCost
	 */
	public float getItemCost() {
		return itemCost;
	}

	/**
	 * setter for itemCost
	 * 
	 * @param itemCost
	 */
	public void setItemCost(float itemCost) {
		this.itemCost = itemCost;
	}

}
