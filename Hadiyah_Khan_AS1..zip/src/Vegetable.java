import java.util.InputMismatchException;
import java.util.Scanner;
/**
 * CET - CS Academic Level 3
 * This class extends FoodItem to add use its methods nad add to them 
 * Student Name: hadiyah Khan
 * Student Number:  041049366
 * Course: CST8130 - Data Structures
 * @author/Professor: James Mwangi PhD. 
 * 
  */
public class Vegetable extends FoodItem {
	/**
	 * private variable string farmName
	 */
	private String farmName;

	/**
	 * class vegetabel constrctor, initilise farmname variable
	 */
	public Vegetable() {
		super();
		this.farmName = "";

	}

	/**
	 * add the vegetable farm name to the toString
	 */
	public String toString() {

		return super.toString() + "\n Farm Name: " + this.farmName;
	}

	/**
	 * ask the input for the vegitable farm name
	 */
	public boolean addItem(Scanner scanner) {
		if (!super.addItem(scanner)) {
			return false;
		}
		try {
			System.out.println("Enter the name of the farm supplier: ");
			this.farmName = scanner.next();
		} catch (InputMismatchException e) {
			System.out.println("invalid input: enter characters");
			scanner.nextLine();
		}
		return true;

	}

}
