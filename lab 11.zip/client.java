import java.net.*;
import java.util.Random;
import java.io.*;

public class client{
	
	private static String serverIP;
	private static DataInputStream input;
	private static DataOutputStream output ;
	
	
	
	public static void main(String[] args) throws IOException  {
		Socket simpleClient = new Socket (serverIP , 1254);	
		  
		 
		  
		  
	}
	

	

		
	


	
	
	}
	
	
	

	


