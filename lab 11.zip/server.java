import java.net.*;
import java.io.*;

public class server {

	private static DataInputStream input;
	private static DataOutputStream output ;
	private static String serverIP;
	static BufferedReader reader ;
	
	
	public static void main(String[] args) throws IOException  {
		ServerSocket simpleServer = new ServerSocket(1254);
		Socket simpleClient = simpleServer.accept();
		
		
		System.out.println("hello from server");
		
		
		 BufferedReader reader = new BufferedReader(  new InputStreamReader(simpleClient.getInputStream()));
		 
	
	}
}