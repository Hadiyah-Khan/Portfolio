package lab3;

public class Queen extends Piece {

	@Override
	void getValidMoves(int row, int col) {
		// TODO Auto-generated method stub
		
	}

	@Override
	String getSymbol() {
		// TODO Auto-generated method stub
		return "q";
	}

	@Override
	String getName() {
		// TODO Auto-generated method stub
		return null;
	}

}
