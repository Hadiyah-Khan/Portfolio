package lab3;

public class Board {

	void printBox(String[][] piece, int rows, String left, String right) {

		for (int i = 0; i < piece[rows].length; i++) { // for the left side of the box pattern
 
			if (i == 0) {
				System.out.print("  ");
			}
			System.out.print(left);

		}

		if (piece[rows].length != 0) { // for the left side of the box pattern

			System.out.println(right);

		}

	}

	void printSquare(String[][] piece) {

		for (int rows = 0; rows < piece.length; rows++) { // loop for the 2 demensional array- rows (1st part)

			if (rows == 0) {
				System.out.print("  ");
				for (int cols = 0; cols < piece[rows].length; cols++) { // loop for the 2 demensional array- collums
																		// (2nd
					// part)

					System.out.print("   " + (cols+1) + "  "); // middle of the box

				}

				if (piece[rows].length != 0) {

					System.out.println(" "); // if the collums are 0 = dont print

				}
			}

			printBox(piece, rows, "+-----", "+");
			printBox(piece, rows, "|     ", "|"); // top of the box

			for (int cols = 0; cols < piece[rows].length; cols++) { // loop for the 2 demensional array- collums (2nd
																	// part)

				if (cols == 0) {
					System.out.print((rows+1) + " ");
				}
				
				System.out.print("|  " + piece[rows][cols] + "  "); // middle of the box

				
				
			}

			if (piece[rows].length != 0) {

				System.out.println("|"); // if the collums are 0 = dont print

			}

			printBox(piece, rows, "|     ", "|");

		}

		printBox(piece, piece.length - 1, "+-----", "+");// bottom part of the box
	}
	
	void chessPiece(Piece[][] Array, String[][] MyArray) {
		
		for (int j = 0; j< 8; j++) {
			Array[1][j] = new Pawn(); // pawns for white peices 
			
			MyArray[1][j] = Array[1][j].getSymbol(); // pawns for white peices 
		}
		
		for (int j = 0; j< 8; j++) {
			Array[6][j] = new Pawn();
			
			MyArray[6][j] = Array[6][j].getSymbol().toUpperCase(); // pawns for black peices 
		}
		
		Array [0][0] = new Rook();
		MyArray [0][0] = Array [0][0].getSymbol(); // rooks for white pieces 
		
		
		Array [0][7] = new Rook();
		MyArray [0][7] = Array [0][7].getSymbol();
		
		
		Array [7][0] = new Rook();
		MyArray [7][0] = Array [7][0].getSymbol().toUpperCase(); // rooks for black pieces
		
		
		Array [7][7] = new Rook();
		MyArray [7][7] = Array [7][7].getSymbol().toUpperCase();
		
		
		
		
		Array [0][1] = new Knight();
		MyArray [0][1] = Array [0][1].getSymbol(); // white peices for knights 
		
		
		Array [0][6] = new Knight();
		MyArray [0][6] = Array [0][6].getSymbol();
		
		
		Array [7][1] = new Knight();
		MyArray [7][1] = Array [7][1].getSymbol().toUpperCase(); // black peices for knights 
		
		
		Array [7][6] = new Knight();
		MyArray [7][6] = Array [7][6].getSymbol().toUpperCase();
		
		
		
		Array [0][2] = new Bishop();
		MyArray [0][2] = Array [0][2].getSymbol(); // white peices for Bishop
		
		
		Array [0][5] = new Bishop();
		MyArray [0][5] = Array [0][5].getSymbol();
		
		Array [7][2] = new Bishop();
		MyArray [7][2] = Array [7][2].getSymbol().toUpperCase(); // black peices for bishop
		
		
		Array [7][5] = new Bishop();
		MyArray [7][5] = Array [7][5].getSymbol().toUpperCase();
		
		
		Array [0][3] = new King();
		MyArray [0][3] = Array [0][3].getSymbol(); // white peices for King
		
		
		Array [0][4] = new Queen();
		MyArray [0][4] = Array [0][4].getSymbol(); // white peice for Queen 
		
		Array [7][3] = new King();
		MyArray [7][3] = Array [7][3].getSymbol().toUpperCase(); // black peices for King
		
		
		Array [7][4] = new Queen();
		MyArray [7][4] = Array [7][4].getSymbol().toUpperCase(); // black Pieve for Queen
		
	
		
	}

}
