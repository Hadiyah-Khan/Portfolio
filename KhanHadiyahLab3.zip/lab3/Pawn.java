package lab3;

import java.util.ArrayList;
import java.util.Arrays;

class Pawn extends Piece {

	@Override
	void getValidMoves(int row, int col) {
		String colour = null;
		
		int actualRow = row - 1;
		int actualCol = col - 1;
		int[][] validWhiteMoves = { { row + 1, col }, { row + 2, col }, { row + 1, col + 1 }, { row + 1, col - 1 } };
		int[][] validBlackMoves = { { row - 1, col }, { row - 2, col }, { row - 1, col + 1 }, { row - 1, col - 1 } };
		ArrayList<String> Moves = new ArrayList<String>();

		for (int i = 0; i < validWhiteMoves.length; i++) {

			Moves.add(Arrays.toString(validWhiteMoves[i]));
			
			

		}
		
		if(Lab3.Piece[actualRow][actualCol] == "p") {
			
			colour = "white";
			System.out.println(getName());
			
			if (actualRow != 7) {  // for white moves 

				if (Lab3.Piece[actualRow + 1][actualCol] != " ") {

					Moves.set(0, null);

				}

			} else {

				Moves.set(0, null);

			}

			if (actualRow != 6) {

				if (Lab3.Piece[actualRow + 2][actualCol] != " ") {

					Moves.set(1, null);

				}

			} else {

				Moves.set(1, null);

			}

			if (actualRow != 7 && actualCol != 7) {

				if (Lab3.Piece[actualRow + 1][actualCol + 1] != " ") {

					Moves.set(2, null);
				}

			} else {
				Moves.set(2, null);
			}
			
			if (actualRow != 7 && actualCol != 0) {

				if (Lab3.Piece[actualRow + 1][actualCol - 1] != " ") {

					Moves.set(3, null);
				}

			} else {
				Moves.set(3, null);
			}
			
			
			
			
		}else if(Lab3.Piece[actualRow][actualCol] == "P") {
			
			colour = "balck";
			System.out.println(getName());
			
			for (int i = 0; i < validBlackMoves.length; i++) {

				Moves.add(Arrays.toString(validBlackMoves[i]));
				
			}
			
			
			if (actualRow != 0) {  // for white moves 

				if (Lab3.Piece[actualRow - 1][actualCol] != " ") {

					Moves.set(0, null);

				}

			} else {

				Moves.set(0, null);

			}

			if (actualRow != 1) {

				if (Lab3.Piece[actualRow - 2][actualCol] != " ") {

					Moves.set(1, null);

				}

			} else {

				Moves.set(1, null);

			}

			if (actualRow != 0 && actualCol != 0) {

				if (Lab3.Piece[actualRow - 1][actualCol - 1] != " ") {

					Moves.set(2, null);
				}

			} else {
				Moves.set(2, null);
			}
			
			if (actualRow != 0 && actualCol != 7) {

				if (Lab3.Piece[actualRow - 1][actualCol + 1] != " ") {

					Moves.set(3, null);
				}

			} else {
				Moves.set(3, null);
			}
			
			
		}
	

		System.out.print(Moves);
	}

	@Override
	String getSymbol() {
		// TODO Auto-generated method stub
		return "p";
	}

	@Override
	String getName() {
		
		
		return String.format("The piece at that location is a %s pawn.", colour);
	}

}
