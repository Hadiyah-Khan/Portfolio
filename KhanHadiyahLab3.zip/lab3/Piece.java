package lab3;

public abstract class Piece {
	// boolean for piece colour. true = black, false = white 4
	
	boolean colour; // initialise to false-white

	
	private int row; 
	
	abstract void getValidMoves(int row, int col);
	abstract String getSymbol();
	abstract String getName();
	
}

