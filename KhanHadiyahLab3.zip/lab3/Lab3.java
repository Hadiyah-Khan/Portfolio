
package lab3;

import java.util.Scanner;

public class Lab3 {

	Scanner s = new Scanner(System.in);


	static Pawn pawn = new Pawn();
	static Rook rook = new Rook();
	static Board b = new Board();
	static Piece ps;
	final static int rows = 8;
	final static int cols = 8;

	static String[][] Piece = new String[rows][cols];

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Lab3 lab3 = new Lab3();

		Piece[][] p = new Piece[rows][cols];

		String choice;

		for (int i = 0; i < Piece.length; i++) {
			for (int j = 0; j < Piece[i].length; j++) {
				Piece[i][j] = " ";
			}
		}
		b.chessPiece(p, Piece);  // call on chess piece from class board 
		b.printSquare(Piece); // call method print square from class board to print the board
		
		lab3.menu();
		
		
		
//		do {
//			choice = lab3.menu();  // do while loop- execute menu method until choice equals Q
//		} while (choice != "Q");
//
	}

	void movePiece(String[][] Array) {  // method to move piece. 

		int row;
		int col;
		int newRow;
		int newCol;

		System.out.println("What pieces do you wish to move? :  ");

		do {

			System.out.print("enter row : ");

			if (s.hasNextInt()) {
				row = s.nextInt();
				if (row < 9 && row > 0) {
					break;
				}

				System.out.println("input must be between the range of 1-8 : ");
				continue;
			}

			System.out.println("input must be an integer");
			s.next();

		} while (true);

		do {
			System.out.print("enter column : ");
			if (s.hasNextInt()) {
				col = s.nextInt();
				if (col < 8 && col > 0) {
					break;
				}

				System.out.println("input must be between the range of 1-8 : ");
				continue;
			}

			System.out.println("input must be an integer");
			s.next();

		} while (true);

		String Piece = Array[row - 1][col - 1];
		Array[row - 1][col - 1] = " ";

		System.out.println("Where do you wish to move the piece? :  ");
		do {

			System.out.print("enter row : ");

			if (s.hasNextInt()) {
				newRow = s.nextInt();
				if (newRow < 9 && newRow > 0) {
					break;
				}

				System.out.println("input must be between the range of 1-8 : ");
				continue;
			}

			System.out.println("input must be an integer");
			s.next();

		} while (true);

		do {

			System.out.print("enter column : ");
			if (s.hasNextInt()) {
				newCol = s.nextInt();
				if (newCol < 8 && newCol > 0) {
					break;
				}

				System.out.println("input must be between the range of 1-8 : ");
				continue;
			}

			System.out.println("input must be an integer");
			s.next();
		} while (true);

		Array[newRow - 1][newCol - 1] = Piece;

	}

	void menu() { // method menue 
		
		
		final String CHOICE_1 = "1";
		final String CHOICE_2 = "2";
		final String CHOICE_3 = "3";
		final String CHOICE_EXIT = "Q" ;
		String choice;
		do {	
	System.out.println("--------------------------------meneu--------------------------");
	System.out.println( CHOICE_1 + " Move Peice");
	System.out.println( CHOICE_2 + " Check a piece for valid moves");
	System.out.println( CHOICE_3 + " Redraw the board");
	System.out.println( CHOICE_EXIT + " to exit the program");
	System.out.println("enter choice( valid options are :1, 2, 3 or Q) :   ");
	choice = s.next();
	
	
		
		switch (choice) {
		
		case CHOICE_1 :
			movePiece(Piece);
			break;
			
		case CHOICE_2:
			int row;
			int col;
			System.out.println("What pieces do you wish to check? :  ");
			do {

				System.out.println("enter row : ");

				if (s.hasNextInt()) {
					row = s.nextInt();
					if (row < 9 && row > 0) {
						break;
					}

					System.out.println("input must be between the range of 1-8 : ");
					continue;
				}

				System.out.println("input must be an integer");
				s.next();

			} while (true);

			do {
				System.out.print("enter column : ");
				if (s.hasNextInt()) {
					col = s.nextInt();
					if (col < 8 && col > 0) {
						break;
					}

					System.out.println("input must be between the range of 1-8 : ");
					continue;
				}

				System.out.println("input must be an integer");
				s.next();

			} while (true);
          
			
			if (Piece[row-1][col-1].equalsIgnoreCase("p")) {
				pawn.getValidMoves(row, col);
				
			
				
			}else if(Piece[row-1][col-1].equalsIgnoreCase("r")) {
				rook.getValidMoves(row, col);
				
			}
			
//			
//			if(Piece[row-1][col-1].equals("p")) {
//				pawn.getName();
//			}else if(Piece[row-1][col-1].equals("P")) {
//				pawn.getName();
//			}else if (Piece[row-1][col-1].equals("r")) {
//				rook.getName();
//			}else if(Piece[row-1][col-1].equals("R")){
//				rook.getName();
//			}
				
		
			
		
			
	//	rook.getValidMoves(row, col);
			
			//.getValidMoves(row - 1, col - 1);
			break;
			
		case CHOICE_3 :
			b.printSquare(Piece);
			break;
		case CHOICE_EXIT:
			System.out.println("Program will shutdown");
			break;

		default:
			System.out.println("invalid input you fucked up"); //edit this once done to be more school friendy 

			
		}
		
	}while (choice != CHOICE_EXIT);
	
	} 
		/*
	
		System.out.println("1. Move a piece.\r\n" + "2. Check a piece for valid moves.\r\n" + "3. Redraw the board.\r\n"
				+ "Q. Quit.");

		System.out.print("enter choice: ");

		String choice = s.next();

		do {
		
		switch (choice) {

		case "1":
			movePiece(Piece);
			break;

		case "2":
			int row;
			int col;

			System.out.println("What pieces do you wish to check? :  ");

			do {

				System.out.print("enter row : ");

				if (s.hasNextInt()) {
					row = s.nextInt();
					if (row < 9 && row > 0) {
						break;
					}

					System.out.println("input must be between the range of 1-8 : ");
					continue;
				}

				System.out.println("input must be an integer");
				s.next();

			} while (true);

			do {
				System.out.print("enter column : ");
				if (s.hasNextInt()) {
					col = s.nextInt();
					if (col < 8 && col > 0) {
						break;
					}

					System.out.println("input must be between the range of 1-8 : ");
					continue;
				}

				System.out.println("input must be an integer");
				s.next();

			} while (true);

			ps.getValidMoves(row - 1, col - 1);
			break;

		case "3":
			b.printSquare(Piece);
			break;
		case "Q":

			System.out.println("Program will shutdown");
			break;

		default:
			System.out.println("invalid input you fucked up"); //edit this once done to be more school friendy 

		}


		return choice;
		
}while (choice != "Q");
	}
*/
}
