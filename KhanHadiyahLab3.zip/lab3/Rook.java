package lab3;

import java.util.ArrayList;
import java.util.Arrays;

public class Rook extends Piece {

	
	String colour;
	@Override
	void getValidMoves(int row, int col) {
		// TODO Auto-generated method stub
		int actualRow = row - 1;
		int actualCol = col - 1;
		ArrayList<String> a = new ArrayList<>();

		int[] array = { row, col };
		int[] actualArray = { actualRow, actualCol };
		

		if(Lab3.Piece[actualRow][actualCol].equals("r")) {
			
			colour = "white";
			
			System.out.println(getName());
			
			for (int i = 1; i <= 8; i++) {
				array[0]++;
				actualArray[0]++;
				if (actualArray[0] < 8) {
					if (Lab3.Piece[actualArray[0]][actualArray[1]] != " " && (Lab3.Piece[actualArray[0]][actualArray[1]]
							.equals(Lab3.Piece[actualArray[0]][actualArray[1]].toLowerCase()))) {
						array[0]-= i;
						actualArray[0]-= i;
						break;
						

					} else if(Lab3.Piece[actualArray[0]][actualArray[1]] != " " && (Lab3.Piece[actualArray[0]][actualArray[1]]
							.equals(Lab3.Piece[actualArray[0]][actualArray[1]].toUpperCase()))) {
						a.add(Arrays.toString(array));
						array[0]-= i;
						actualArray[0]-= i;
						break;

					}
				} else {
					array[0]-= i;
					actualArray[0]-= i;
					break;

				}
				a.add(Arrays.toString(array));
				
			}
			
			
		
			for (int i = 1; i <= 8; i++) {
				array[0]--;
				actualArray[0]--;
				if (actualArray[0] > -1) {
					
				
					if (Lab3.Piece[actualArray[0]][actualArray[1]] != " " && (Lab3.Piece[actualArray[0]][actualArray[1]]
							.equals(Lab3.Piece[actualArray[0]][actualArray[1]].toLowerCase()))) {
						array[0]+= i;
						actualArray[0]+= i;
						break;
						

					} else if(Lab3.Piece[actualArray[0]][actualArray[1]] != " " && (Lab3.Piece[actualArray[0]][actualArray[1]]
							.equals(Lab3.Piece[actualArray[0]][actualArray[1]].toUpperCase()))) {
						a.add(Arrays.toString(array));
						array[0]+= i;
						actualArray[0]+= i;
						break;

					}
				} else {
					array[0]+= i;
					actualArray[0]+= i;
					break;

				}
				a.add(Arrays.toString(array));
				
			}		
			
			//kjjjjkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk
			
			for (int i = 1; i <= 8; i++) {
				array[1]++;
				actualArray[1]++;
				if (actualArray[1] < 8) {
					if (Lab3.Piece[actualArray[0]][actualArray[1]] != " " && (Lab3.Piece[actualArray[0]][actualArray[1]]
							.equals(Lab3.Piece[actualArray[0]][actualArray[1]].toLowerCase()))) {
						array[1]-= i;
						actualArray[1]-= i;
						break;
						

					} else if(Lab3.Piece[actualArray[0]][actualArray[1]] != " " && (Lab3.Piece[actualArray[0]][actualArray[1]]
							.equals(Lab3.Piece[actualArray[0]][actualArray[1]].toUpperCase()))) {
						a.add(Arrays.toString(array));
						array[1]-= i;
						actualArray[1]-= i;
						break;

					}
				} else {
					array[1]-= i;
					actualArray[1]-= i;
					break;

				}
				a.add(Arrays.toString(array));
				
			}
			
			
		
			for (int i = 1; i <= 8; i++) {
				array[1]--;
				actualArray[1]--;
				if (actualArray[1] > -1) {
					if (Lab3.Piece[actualArray[0]][actualArray[1]] != " " && (Lab3.Piece[actualArray[0]][actualArray[1]]
							.equals(Lab3.Piece[actualArray[0]][actualArray[1]].toLowerCase()))) {
						array[1]+= i;
						actualArray[1]+= i;
						break;
						

					} else if(Lab3.Piece[actualArray[0]][actualArray[1]] != " " && (Lab3.Piece[actualArray[0]][actualArray[1]]
							.equals(Lab3.Piece[actualArray[0]][actualArray[1]].toUpperCase()))) {
						a.add(Arrays.toString(array));
						array[1]+= i;
						actualArray[1]+= i;
						break;

					}
				} else {
					array[1]+= i;
					actualArray[1]+= i;
					break;

				}
				a.add(Arrays.toString(array));
				
			}		
			
		}else if(Lab3.Piece[actualRow][actualCol].equals("R")) {
			
			colour = "black";
			System.out.println(getName());
			
			for (int i = 1; i <= 8; i++) {
				array[0]++;
				actualArray[0]++;
				if (actualArray[0] < 8) {
					if (Lab3.Piece[actualArray[0]][actualArray[1]] != " " && (Lab3.Piece[actualArray[0]][actualArray[1]]
							.equals(Lab3.Piece[actualArray[0]][actualArray[1]].toUpperCase()))) {
						array[0]-= i;
						actualArray[0]-= i;
						break;
						

					} else if(Lab3.Piece[actualArray[0]][actualArray[1]] != " " && (Lab3.Piece[actualArray[0]][actualArray[1]]
							.equals(Lab3.Piece[actualArray[0]][actualArray[1]].toLowerCase()))) {
						a.add(Arrays.toString(array));
						array[0]-= i;
						actualArray[0]-= i;
						break;

					}
				} else {
					array[0]-= i;
					actualArray[0]-= i;
					break;

				}
				a.add(Arrays.toString(array));
				
			}
			
			
		
			for (int i = 1; i <= 8; i++) {
				array[0]--;
				actualArray[0]--;
				if (actualArray[0] > -1) {
					if (Lab3.Piece[actualArray[0]][actualArray[1]] != " " && (Lab3.Piece[actualArray[0]][actualArray[1]]
							.equals(Lab3.Piece[actualArray[0]][actualArray[1]].toUpperCase()))) {
						array[0]+= i;
						actualArray[0]+= i;
						break;
						

					} else if(Lab3.Piece[actualArray[0]][actualArray[1]] != " " && (Lab3.Piece[actualArray[0]][actualArray[1]]
							.equals(Lab3.Piece[actualArray[0]][actualArray[1]].toLowerCase()))) {
						a.add(Arrays.toString(array));
						array[0]+= i;
						actualArray[0]+= i;
						break;

					}
				} else {
					array[0]+= i;
					actualArray[0]+= i;
					break;

				}
				a.add(Arrays.toString(array));
				
			}		
			
			//kjjjjkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk
			
			for (int i = 1; i <= 8; i++) {
				array[1]++;
				actualArray[1]++;
				if (actualArray[1] < 8) {
					if (Lab3.Piece[actualArray[0]][actualArray[1]] != " " && (Lab3.Piece[actualArray[0]][actualArray[1]]
							.equals(Lab3.Piece[actualArray[0]][actualArray[1]].toUpperCase()))) {
						array[1]-= i;
						actualArray[1]-= i;
						break;
						

					} else if(Lab3.Piece[actualArray[0]][actualArray[1]] != " " && (Lab3.Piece[actualArray[0]][actualArray[1]]
							.equals(Lab3.Piece[actualArray[0]][actualArray[1]].toLowerCase()))) {
						a.add(Arrays.toString(array));
						array[1]-= i;
						actualArray[1]-= i;
						break;

					}
				} else {
					array[1]-= i;
					actualArray[1]-= i;
					break;

				}
				a.add(Arrays.toString(array));
				
			}
			
			
		
			for (int i = 1; i <= 8; i++) {
				array[1]--;
				actualArray[1]--;
				if (actualArray[1] > -1) {
					if (Lab3.Piece[actualArray[0]][actualArray[1]] != " " && (Lab3.Piece[actualArray[0]][actualArray[1]]
							.equals(Lab3.Piece[actualArray[0]][actualArray[1]].toUpperCase()))) {
						array[1]+= i;
						actualArray[1]+= i;
						break;
						

					} else if(Lab3.Piece[actualArray[0]][actualArray[1]] != " " && (Lab3.Piece[actualArray[0]][actualArray[1]]
							.equals(Lab3.Piece[actualArray[0]][actualArray[1]].toLowerCase()))) {
						a.add(Arrays.toString(array));
						array[1]+= i;
						actualArray[1]+= i;
						break;
						
					}
				} else {
					array[1]+= i;
					actualArray[1]+= i;
					break;

				}
				a.add(Arrays.toString(array));
				
			}	
			
		}
		
		System.out.println(a);
		
	}

	@Override
	String getSymbol() {
		// TODO Auto-generated method stub
		return "r";
	}

	@Override
	String getName() {
		// TODO Auto-generated method stub
		return String.format("The piece at that location is a %s rook.", colour);
	}

}
