import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * This class contains the dynamically allocated array and it's processing
 * Student Name: Hadiyah Khan Student Number: 041049366 Course: CST8130 - Data
 * Structures CET-CS-Level 3
 * 
 * @author/Professor James Mwangi PhD.
 * 
 */

public class Numbers {
	static float min;
	static float max;
	static String fileName;
	static String fileNames;
	/**
	 * Stores Float values.
	 */
	private static Float[] numbers;

	/**
	 * Store the number of items currently in the array.
	 */
	private static int numItems;

	/**
	 * Default Constructor
	 * 
	 * 
	 */
	public Numbers() {
		// TODO Write code here to initialize a "default" array since this is the
		// default construct
		numItems = 0;

		numbers = new Float[4];
	}

	/**
	 * Constructor that initializes the numbers array.
	 * 
	 * @param size - Max size of the numbers array
	 */
	public Numbers(int size) {
		// TODO Write code here to initialize the numbers array of max 'size'
		// System.out.println("entre new size of array: ");
		// Scanner input = new Scanner(System.in);

		numbers = new Float[size];

	}

	/**
	 * Adds a value in the array
	 * 
	 * @param keyboard - Scanner object to use for input
	 */
	public static void addValue(Scanner keyboard, boolean isFile) {
		// TODO Write code here to add the values in the array
		while (true) {

			try {

				System.out.println("enter value ");
				Scanner input = new Scanner(System.in);

				numbers[numItems] = input.nextFloat();
				numItems++;

			} catch (InputMismatchException e) {
				System.out.println("please enter a valid numbers");

			} catch (NullPointerException e) {
				System.out.println("Array not initialized");
			}
		}

	}

	/*
	 * adds multiple values to the array at once
	 * 
	 * @param input - Scanner object to use for input
	 */
	public static void addValues(Scanner input, boolean isFile) {

		// only add 4 values into 10 elements

		try {

			/*
			 * numItmes is the current numbers of floats inside the array
			 */

			int count;
			System.out.print("How many values do you wish to add ");

			count = input.nextInt();

			while (true) {
				if (numItems == count) {
					break;
				}
				System.out.print("enter value: ");
				numbers[numItems] = input.nextFloat();
				numItems++;
			}

		} catch (InputMismatchException e) {
			System.out.println("please enter a valid numbers ");

		} catch (NullPointerException e) {
			System.out.println("Array not initialized");
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("Array is full; only the values that fit into the array will be displayed");
		}

	}

	/**
	 * Calculates the average of all the values in the numbers array.
	 * 
	 * @return float value that represents the average
	 */
	public static float calcAverage() {
		// TODO Write code to return the average of the values in the array

		float total = 0;
		try {
			for (int i = 0; i < numItems; i++) {
				total = numbers[i] + total;
			}
			total = total / numItems;
			System.out.println(" average is " + total);

		} catch (NullPointerException e) {
			System.out.println("Array is not initialized, please select option 1 or 2");

		}

		return (float) 0.00;
	}

	/*
	 * finds min and max values from the float numbers from the array
	 */
	public static float findMinMax() {
		try {
			min = numbers[0];
			max = numbers[0];
			for (int i = 0; i < numItems; i++) {

				if (numbers[i] < min) {
					min = numbers[i];
				}
			}
			for (int i = 0; i < numItems; i++) {
				if (numbers[i] > max) {
					max = numbers[i];
				}
			}
			float mod = max % min;
			System.out.println(" , minimum value is : " + min + ", maximum value is: " + max + ", max mod min : + mod");
		} catch (NullPointerException e) {
			System.out.println("Array is not initialized, please select option 1 or 2");

		}
		return (float) 0.00;

	}

	public static float getfactorialMax() {
		if (max == 0) {
			System.out.println(", factorial of max is : 1");

		} else {
			Float factor = (float) Math.round(max);
			for (int i = 1; i < max; i++) {
				factor = factor + i;

			}
			System.out.println(", factorial of max is : " + factor);

		}

		return (float) 0.00;

	}

	public static void readFromFile(Scanner input) {

		System.out.println("Enter File name:");
		String fileName = input.next();

		System.out.println(" reading from " + fileName);
		System.out.println(".");
		System.out.println(".");
		System.out.println(".");
		System.out.println(".");
		System.out.println(".");

	
		int currentIndex = 0;
		 try {
			 File file = new File(fileName);
	            input = new Scanner(file);
	            int size = input.nextInt();
	            while (input.hasNextFloat() && numItems < numbers.length) {
	                numbers[numItems] = input.nextFloat();
	                numItems++;
	            }
	            input.close();

//	            // Print the array
//	            for (int i = 0; i < numItems; i++) {
//	                System.out.print(numbers[i] + " ");
//	            }
	        } catch (FileNotFoundException e) {
	            e.printStackTrace();
	        }
		
	

		
		

	
			
	}

	
	 /* saves float values from array into a file
	 * 
	 * @param input - Scanner object to use for input
	 */
	public void saveToFile(Scanner input) throws FileNotFoundException {

		System.out.println("Name of the file to save to:");
		String fileName = input.next();
		File file = new File(fileName);
		try (PrintWriter writer = new PrintWriter(file)) {
			writer.println(numItems);
			for (float value : numbers) {

				writer.println(value);
			}
		} catch (FileNotFoundException e) {
			System.out.println("File not found: " + file);
		} catch (NullPointerException e) {

		}

	}

	/*
	 * reads the file and saves the read values back into the original array
	 * 
	 * @param input - Scanner object to use for input
	 */

	public String toString() {
		// TODO Write code for an appropriate toString method
		
//		
//		   
		String newNumbers;
		
		for (int i = 0; i < numbers.length ; i++) {
			if (numbers[i] != null) {
				newNumbers = numbers[i].toString();
				System.out.println(newNumbers);
			}
			
			
		}
		
           //return Arrays.toString(numbers);
		return "";
           
          

	}

}

