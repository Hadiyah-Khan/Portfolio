import java.util.Comparator;

public class FoodItemComparator implements Comparator<FoodItem> {
	@Override

	public int compare(FoodItem o1, FoodItem item) {
		
		if(o1.getItemCode() < item.getItemCode()) {
			
			return -1;
			
		}else if(o1.getItemCode() == item.getItemCode()){
			return 0;
		}else {
			return 1;
		}
	}
}
