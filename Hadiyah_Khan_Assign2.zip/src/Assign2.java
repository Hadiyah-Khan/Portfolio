import java.util.Scanner;
import java.util.regex.Pattern;

/**
 * CET - CS Academic Level 3 This class extends FoodItem to add use its methods
 * nad add to them Student Name: hadiyah Khan Student Number: 041049366 Course:
 * CST8130 - Data Structures
 * 
 * @author/Professor: James Mwangi PhD.
 * 
 */
public class Assign2 {
	/**
	 * private vairable for option 1 for the switch case
	 */
	private final static int CHOICE_1 = 1;
	/**
	 * private vairable for option 2 for the switch case
	 */
	private final static int CHOICE_2 = 2;
	/**
	 * private vairable for option 3 for the switch case
	 */
	private final static int CHOICE_3 = 3;
	/**
	 * private vairable for option 4 for the switch case
	 */
	private final static int CHOICE_4 = 4;
	/**
	 * private vairable for option 5 for the switch case
	 */
	private final static int CHOICE_5 = 5;

	/**
	 * private variable for option 6 for the switch case
	 */
	private final static int CHOICE_6 = 6;
	/**
	 * private varaiable for option 7 for the switch case
	 */
	private final static int CHOICE_7 = 7;
	/**
	 * private variable for option 8 for the sqwitch case
	 */
	private final static int CHOICE_8 = 8;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/**
		 * new Scanner object input
		 */
		Scanner input = new Scanner(System.in);
		/**
		 * new obect of the inventory class called i
		 */
		Inventory i = new Inventory();

		input.useDelimiter(Pattern.compile("[\\r\\n]+"));
		/**
		 * int variable that will be used in in the user input
		 */
		int choice = 0;
		while (choice != 8) { // run code while choice does not equal 8 - option 8 is for exiting the program
			try {
				displauMenu(); // method displayMenu is called
				if (input.hasNext(Pattern.compile("[1-8]"))) {
					choice = input.nextInt();

					switch (choice) { // case switch is used to call methods form inventory that correspond to the
					// diffrent choices

					case CHOICE_1: // add item to inventory
						if (!i.addItem(input, false))
							System.out.println("Error...could  not add item");
						break;
//							

					case CHOICE_2:
						System.out.println(i); // option 2, print out everything inside the inventory

						break;

					case CHOICE_3: // option 3 to call the method to buy an item
						if (!i.updateQuantity(input, true))
							System.out.println("Error...could  not buy item");
						break;

					case CHOICE_4: // option 4 to call the method to sell an item
						if (!i.updateQuantity(input, false))
							System.out.println("Error...could not sell item");
						break;

					case CHOICE_5:
						i.searchForItem(input); // option 5 to call method that searches for item

						break;

					case CHOICE_6:
						i.saveToFile(input); // option 6 to call method to save items to file of users prefrence

						break;

					case CHOICE_7:
						i.readFromFile(input); /// option 7 to call method that reads from a file that user chooses
						break;

					case CHOICE_8:
						System.out.println("exitng"); // option to exit the program
						System.out.println(".");
						System.out.println(".");
						System.out.println(".");
						System.out.println(".");
						System.out.println(".");
						System.out.println(".");
						System.out.println(".");

					default:
						System.out.println("invalid input valid integers, try again: valid input: [1,2,3,4,5,6,7,8]  "); // the
						// error
						// for
						// the
						// wrong
						// input
						// in
						// numebers

					}
				} else {
					System.out.println("Incorrect value entered");
					input.next();
				}
			} catch (Exception e) {
				System.out.println("Something went wrong...." + e.getMessage());
			}
			
			i.getList().sort(new FoodItemComparator());
		}
		input.close(); // close the scanner
	}

	/**
	 * method that has the menu options
	 */
	public static void displauMenu() {

		System.out.println("--------------------------------menu--------------------------");
		System.out.println(CHOICE_1 + ": Add Item to Inventory");
		System.out.println(CHOICE_2 + ": Display Current Inventory");
		System.out.println(CHOICE_3 + ": Buy Item(s)");
		System.out.println(CHOICE_4 + ": Sell Item(s)");
		System.out.println(CHOICE_5 + ": Search for item");
		System.out.println(CHOICE_6 + ": Save Invetory to File");
		System.out.println(CHOICE_7 + ": Read Inventory from File");
		System.out.println(CHOICE_8 + ": To Exit");

		System.out.println("enter intput: ");

	}

}
