import java.util.Formatter;
import java.util.Scanner;

/**
 * CET - CS Academic Level 3
 * This class contians methods to be used by inventory nad setters and getters 
 * Student Name: hadiyah Khan
 * Student Number:  041049366
 * Course: CST8130 - Data Structures
 * @author/Professor: James Mwangi PhD. 
 * 
  */
public class FoodItem {
	/**
	 * private integer itemCode - item code code item
	 */
	private int itemCode;
	/**
	 * private string for item name
	 */
	private String itemName;
	/**
	 * private float value for the price of the item
	 */
	private float itemPrice;
	/**
	 * private integer for the quanitiy of item in stock
	 */
	private int itemQuantityInStock;
	/**
	 * private float value for item cost
	 */
	private float itemCost;

	/**
	 * class contructor FoodItem, initialize the variables
	 */
	public FoodItem() {

		this.setItemCode(0);

		this.itemName = "";

		this.itemPrice = 0.00f;

		this.itemQuantityInStock = 0;

		this.itemCost = 0.00f;

	}

	/**
	 * to stirng to return the items in inventory
	 */
	public String toString() {

			return "Item Code: " + this.itemCode + " " + this.itemName + " " + this.itemQuantityInStock + " price: $"
			+ String.format("%.2f", this.itemPrice) + " cost: $" + 
			String.format("%.2f", this.itemCost);


	}

	/**
	 * method to update quantity of items in stock method to
	 * @param amount of items
	 * @return true or false
	 *         items
	 */
	public boolean updateItem(int amount) {

		if(amount < 0 && this.itemQuantityInStock < (amount*-1)) {  						// if removing items - check if there is enough stock
			return false;
			}
		this.itemQuantityInStock += amount;
			return true;
			
	}

	/**
	 *  method to see if item is equal to the code of item
	 * @param item variabel of FoodItem
	 * @return the itemcode of item 
	 *         
	 */
	public boolean isEqual(FoodItem item) {
		return this.itemCode == item.itemCode;

	}

/**
* method to ask user for input for items
* @param scanner object of Scanner
* @return true if there are items to enter method to add items
*  @param fromFile is a boolean variable
* @return
 */
	public boolean addItem(Scanner scanner , boolean fromFile) {
		
		  boolean validInput = false;		// boolean variable 
		    if (!fromFile) {
		        System.out.print("Enter the name for the item: "); 						// Item name 
		        this.itemName = scanner.next();

		        while (!validInput) {
		            System.out.print("Enter the quantity for the item: "); 						// quantity in stock 
		            this.itemQuantityInStock = scanner.nextInt();
		            if (this.itemQuantityInStock < 0) {
		                System.out.println("Invalid input: only positive integers allowed.");			// error message 
		            } else {
		            	validInput = true;    		// if everything is ok boolean variable is true. this pattern is repeated for the other item variabels
		            }
		        }

		        validInput = false;
		        while (!validInput) {
		            System.out.print("Enter the cost for the item: ");						// item cost
		            if (scanner.hasNextFloat()) {
		                this.itemCost = scanner.nextFloat();
		                if (this.itemCost < 0) {
		                	validInput = false;
		                    System.out.println("Invalid input: please enter positive float values.");					// error message 
		                    this.itemCost = 0;
		                } else {
		                	validInput = true;
		                }
		            } else {
		                System.out.println("Invalid input: please enter valid float values.");					// error message 
		                scanner.next();
		                validInput = false;
		            }
		        }

		        validInput = false;
		        while (!validInput) {
		            System.out.print("Enter the sales price of this item: ");						// sales price 
		            if (scanner.hasNextFloat()) {
		                this.itemPrice = scanner.nextFloat();
		                if (this.itemPrice < 0) {
		                	validInput = false;
		                    System.out.println("Invalid input: please enter positive float values.");           // error message 
		                    this.itemPrice = 0;
		                } else {
		                	validInput = true;
		                }
		            } else {
		                System.out.println("Invalid input: please enter valid float values.");           // error message 
		                scanner.next();
		                validInput = false;
		            }
		        }
		    } else {
		        this.itemName = scanner.next();     								// if valid = true then let the user input be equal to the variables 
		        this.itemQuantityInStock = scanner.nextInt();
		        this.itemCost = scanner.nextFloat();
		        this.itemPrice = scanner.nextFloat();
		    }
		    return true;
		}


	

	
	
	/**
	 * setter for itemCode
	 * 
	 * @param itemCode for the code of the item 
	 */
	public void setItemCode(int itemCode) {
		this.itemCode = itemCode;
	}

	
	
	/****************************************** added method !! ****************************************
	
	/**
	 * this method formats all the values. 
	 * @param writer is the formattter 
	 */
	 public void outputItem(Formatter writer) {
		 writer.format("%d\n", itemCode);					/// all values are formatted by their appropirate variable type 
		 writer.format("%s\n", itemName);
		 writer.format("%d\n", itemQuantityInStock);
		 writer.format("%.2f\n", itemCost);
		 writer.format("%.2f\n", itemPrice);
	
	 }
		 /**
			 * getter for itemcode
			 * 
			 * @return itemcode
			 */
			public int getItemCode() {   				// a getter for itemCode
				return itemCode;
			}

			/**
			 * this method is to setinput code to the  number the user entered
			 * @param scanner obect of Scanner
			 * @param b 
			 * @return true mehthod to enter code for item
			 */
			public boolean inputCode(Scanner scanner, boolean fromFile)  {
				boolean validInput = false;
				while(!validInput) {
					if (!fromFile) {
						System.out.println("Enter the code from the file: ");				// item code for when you want to sell or buy items via item code 
					}if (scanner.hasNextInt()) {
						itemCode = scanner.nextInt();
						validInput = true;
					}
					else {
						System.out.println("Invalid code, please enter valid item code");           		// if item code is invalid, print error message 
						scanner.next();
					}
				}
				return validInput;

			}


		
	 
}
