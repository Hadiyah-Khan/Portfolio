import java.util.Formatter;
import java.util.Scanner;
/**
 * CET - CS Academic Level 3
 * This class extends FoodItem to add use its methods nad add to them 
 * Student Name: hadiyah Khan
 * Student Number:  041049366
 * Course: CST8130 - Data Structures
 * @author/Professor: James Mwangi PhD. 
 * 
  */
public class Preserve extends FoodItem {
	/**
	 * private variable itn jarSize
	 */
	private int jarSize;

	/**
	 * class preserve constructor for initializing jar size
	 */
	public Preserve() {
		super();
		this.jarSize = 0;
	}

	/**
	 * // adds the jar size to the to string
	 */
	@Override
	public String toString() {
		return super.toString() + " size in mL : " + this.jarSize;
	}

	/**
	 * asks the name for the jar size
	 */
	@Override
	public boolean addItem(Scanner scanner , boolean fromFile) {
		
		boolean validInput = false;
		
		if (super.addItem(scanner, fromFile)) {
			while (!validInput) {
				if (!fromFile) {
					System.out.println("Enter the size of the jar in millilitres: "); // enter the jar size
					if (scanner.hasNextInt()) {
						this.jarSize = scanner.nextInt();
						if (jarSize < 0) {
							validInput = false;
							System.out.println("invalid input: please enter positive integer values..........");
							jarSize = 0;
						}else {
							validInput = true;
						}
						
					}else {
						System.out.println("invalid input: please enter positive integer values..........");
						scanner.next();
						validInput = false;
					}
				}
			}
			
			
			
			
			
		}
		return true;

		
	}
	/**
	 * this method is to output the item that is formatted 
	 */
	public void outputItem(Formatter writer) {
		writer.format("p\n");
		super.outputItem(writer);
		writer.format("%d\n", this.jarSize);
	}
}
