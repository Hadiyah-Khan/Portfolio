import java.util.Formatter;
import java.util.Scanner;
/**
 * CET - CS Academic Level 3
 * This class extends FoodItem to add use its methods nad add to them 
 * Student Name: hadiyah Khan
 * Student Number:  041049366
 * Course: CST8130 - Data Structures
 * @author/Professor: James Mwangi PhD. 
 * 
  */
public class Vegetable extends FoodItem {
	/**
	 * private variable string farmName
	 */
	private String farmName;

	/**
	 * class vegetable constructor, initialize farm name variable
	 */
	public Vegetable() {
		super();
		this.farmName = "";

	}

	/**
	 * add the vegetable farm name to the toString
	 */
	@Override
	public String toString() {

		return super.toString() + " Farm Name: " + this.farmName;
	}

	/**
	 * ask the input for the vegetable farm name
	 */
	@Override
	public boolean addItem(Scanner scanner, boolean formFile) {
		if (super.addItem(scanner, formFile)) {
			System.out.println("Enter the name of the farm supplier: ");
			this.farmName = scanner.next();
		}
	return true;
	}
	
	/**
	 * this method is to output the item that is formatted 
	 */
	@Override
	public void outputItem(Formatter writer) {
		writer.format("v\n");
		super.outputItem(writer);
		writer.format("%s\n" , this.farmName );
	}
	

}
