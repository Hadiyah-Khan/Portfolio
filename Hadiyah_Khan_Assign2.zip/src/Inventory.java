
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Formatter;
import java.util.InputMismatchException;
import java.util.ListIterator;
import java.util.Scanner;
import java.util.regex.Pattern;


/**
 * CET - CS Academic Level 3 This class has methods to be called upon by the
 * main class Student Name: Hadiyah Khan Student Number: 041049366 Course:
 * CST8130 - Data Structures
 * 
 * @author/Professor: James Mwangi PhD.
 * 
 */
public class Inventory {
	/**
	 * SENTINAL is -1, if index returns -1 , it will return SENTINAL , which means
	 * item does not exist;
	 */
	private static final int SENTINAL = -1;

	/**
	 * string variabel f for fruit in the switch case
	 */
	private static final String CHOICE_1 = "f";
	/**
	 * string variable v for vegetable for switch case
	 */
	private static final String CHOICE_2 = "v";
	/**
	 * string variable p for preserve for switch case
	 */
	private static final String CHOICE_3 = "p";

	/**
	 * 
	 */
	private static final String CHOICE_4 = "b";
	
	
	/**
	 * arrayList of fooodItem called inventory
	 */
	private ArrayList<FoodItem> inventory;

	
	/**
	 * class contructor for inventory makes the array inventory to size 20
	 */
	public Inventory() {
		inventory = new ArrayList<FoodItem>(20);
		

		

	}
	
	public ArrayList<FoodItem> getList(){
		return inventory;
	}

	/**
	 * this method checks for duplicte item code ie. perform binary search to check if item code alrady exists or not
	 * @param item represents the item in array/inventory
	 * @return SENTINAL if the item does not exist
	 */
	public int alreadyExists(FoodItem item) {
		return binarySearch(item.getItemCode(), 0, inventory.size() - 1);  // perfrom binary search to see if item exists

	}

	/**
	 * adds item into the array
	 * 
	 * @param scanner is an object of Scanner
	 * @return true- return true if user input is correct  for everything, if not, an error message is printed
	 */
	public boolean addItem(Scanner scanner, boolean fromFile) {
		boolean validInput = false;
		FoodItem item = null;
		while (!validInput) {
			if (!fromFile)
				System.out.println("--------------------------------meneu_2--------------------------"); // menue 2 to add
			// fruit,
			// vegtitable,
			// priservve or to
			// exit the program
			System.out.println( CHOICE_1 + ": add a fruit ");
			System.out.println( CHOICE_2  + ": add a vegetable");
			System.out.println( CHOICE_3 + ": add a preserve" );  		
			System.out.println(CHOICE_4 +  ": add a bread )");
			System.out.println("please enter (f) , (v) , (p) , (b)");										// this is the second menu
				
				
			if (scanner.hasNext(Pattern.compile("[fFvVpP]"))) {
				String choice = scanner.next();
				switch (choice.toLowerCase()) {
				case CHOICE_1 :
					item = new Fruit(); 										// if user inputs ('f') then code is goes ot the Fruit class 
				case CHOICE_2:
					item = new Vegetable();										// if user inputs ('v') then code goes to the Vegetable vlasss
					break;						
				case CHOICE_3:
					item = new Preserve();										// if user inputs ('p') then code goes to the Preserve class
					break;
				case CHOICE_4:
					item = new Bread();											// if user inputs ('b') then code goes to the Bread class
					break;
				default:
					System.out.println(" please enter valid values (f) (v) (p) (b)"); 				// error message if user inputs anything other than f , v , p  or b 
					scanner.next();
					validInput = false;
					break;
				}
				validInput = true;
			} else {
				System.out.println("please enter valid values, (f), (v) (p) (b) ");					// another error message 
				scanner.next();
				validInput = false;
			}
		}
		if (item.inputCode(scanner, fromFile)) {
			if (alreadyExists(item) < 0) {
				if (item.addItem(scanner, fromFile)) {
					insertItem(item);
					return true;
				}
				return false;
			} else {
				System.out.println("Item code already exists");						// this is user inputs code that already exists. no duplicate code is allowed
				return false;
			}
		}
		return true;
	}

	

	/**
	 * this method updates quantity. this method has the buying and selling code. if an item is sold or bought, the quantity in stock is updated . if there is not enough qunatity in stock to be bought or sold , an error message is printed
	 * @param scanner
	 * @param buyOrSell
	 * @return
	 */
	public boolean updateQuantity(Scanner scanner, boolean buyOrSell) {
		int amount;

		if (inventory.isEmpty()) { // if there are no items, no update, return sentinel
			return false;
		}

		FoodItem temp = new FoodItem();

		temp.inputCode(scanner, false);
		int index = alreadyExists(temp);
		if (index != SENTINAL) { // if index does not return sentinal, execute the following code
			String buySell = buyOrSell ? "buy" : "sell"; // string buySell equals the boolean parameter buyOrSell
			// which are strings buy (true) or sell (false);
			try {
				System.out.print("Enter valid quantity to " + buySell + ": ");
				if (scanner.hasNextInt()) {
					amount = scanner.nextInt();
					if (amount > 0) {
						return inventory.get(index).updateItem(buyOrSell ? amount : amount * -1);
					} else {
						System.out.println(" invalid quantity");
					}

				} else {
					System.out.println(" invalid quantity");
				}
			} catch (InputMismatchException e) {
				System.out.println("invlid input: please enter valid numbers....");
				amount = scanner.nextInt();
			}

		}
		return false;

	}

	/*****************************************   Added Methods !! ********************************************
	 * 
	 */
	/**
	 *  method to search for item. displays item if found. if not, prints ot error message 
	 * @param scanner for user input
	 */
	public void searchForItem(Scanner scanner) {

		FoodItem itemToSearchFor = new FoodItem();
		itemToSearchFor.inputCode(scanner, false);

		int index = binarySearch(itemToSearchFor.getItemCode(), 0, inventory.size() - 1);
		if (index == -1) {
			System.out.println("Code not found in inventory");
		} else {
			System.out.println(inventory.get(index).toString());
		}

	}

	/**
	 * saves items to a file that the user names
	 * 
	 * @param scanner - for user input.
	 */
	public void saveToFile(Scanner scanner) {

		try {
			System.out.println("Enter file name to save to: "); // user enters name of file that they wish to create and
																// save items onto
			String fileName = scanner.next();

			File file = new File(fileName); // new file with the file name
			file.createNewFile(); // creates the file
			file.setWritable(true); // set file to be written to
			Formatter writer = new Formatter(file); // object writer of formatter
			ListIterator<FoodItem> iterator = inventory.listIterator(); // iterate items in the arrayList
			while (iterator.hasNext()) {
				iterator.next().outputItem(writer); // while there are items in the arrayList, write them onto the file
			}
			writer.flush(); // flush the writer
			writer.close(); // close the writer

		} catch (IOException e) {
			System.out.println(" could not creat file, " + e.getMessage());

		} catch (Exception e) {
			System.out.println(" Error: " + e.getMessage());
		}

	}

	/**
	 * this method reads from the file 
	 * @param scanner-for user input 
	 */
	public void readFromFile(Scanner scanner) {

		try {

			System.out.println("Enter the file name to read from : ");
			String fileName = scanner.next();

			File file = new File(fileName);
			if (file.exists()) {
				Scanner fileReader = new Scanner(file);
//				fileReader.useDelimiter("[\\r\\n]+");
				while (fileReader.hasNextLine()) {
					if (!addItem(fileReader, true)) {
						System.out.println(" Error while reading hte file, aboritng process...............");
						break;
					}
				}
			} else {
				System.out.println("FIle not found...........");
			}

		} catch (Exception e) {
			System.out.println(" Error: " + e.getMessage());

		}

	}

	/**
	 * 
	 * @param itemCode - item's code
	 * @param start - start of the array 
	 * @param end - end of the array 
	 * @return- return sentinal if item code is not found 
	 */
	private int binarySearch(int itemCode, int start, int end) {
		int mid = (start + end) / 2;
		if (start > end) {
			return SENTINAL;
		}
		if (inventory.isEmpty()) {
			return SENTINAL;
		}
		if (inventory.get(mid).getItemCode() == itemCode) {
			return mid;
		}
		if (inventory.get(mid).getItemCode() > itemCode) {
			return binarySearch(itemCode, start, mid - 1);

		}
		if (inventory.get(mid).getItemCode() < itemCode) {
			return binarySearch(itemCode, mid + 1, end);
		}

		return SENTINAL;

	}

	/**
	 * insets item checker
	 * @param item
	 */
	private void insertItem(FoodItem item) {
		FoodItemComparator comp = new FoodItemComparator();
		for (int i = 0; i < inventory.size(); i++) {
			if (((Comparator<FoodItem>) comp).compare(inventory.get(i), item) >= 0) {
				inventory.add(i, item);
				return;
			}
		}

		inventory.add(item);
	}

	@Override
	/**
	 * to string method
	 */
	public String toString() {
		String returnString = "Inventory:\n";
		ListIterator<FoodItem> items = inventory.listIterator();
		while (items.hasNext())
			returnString += items.next().toString() + "\n";
		return returnString;
	}

}
