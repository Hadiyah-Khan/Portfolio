import java.util.Formatter;
import java.util.Scanner;
/**
 * CET - CS Academic Level 3
 * This class extends FoodItem to add use its methods nad add to them 
 * Student Name: hadiyah Khan
 * Student Number:  041049366
 * Course: CST8130 - Data Structures
 * @author/Professor: James Mwangi PhD. 
 * 
  */
public class Fruit extends FoodItem {
	/**
	 * private string variable for orchard name
	 */
	private String orchardName;

	/**
	 * class fruit constructor for initializing orchard name
	 */
	public Fruit() {
		super();
		this.orchardName = "";
	}

	/**
	 * // adds orchard name to the toStirng
	 */
	@Override
	public String toString() {

		return super.toString() + " Orchard supplier : " + this.orchardName;
	}

	/**
	 * to add the orchard name
	 */
	@Override
	public boolean addItem(Scanner scanner, boolean formFile) {
	    if (super.addItem(scanner, formFile)) {
	    	if (!formFile)
				System.out.print("Enter the name of the orchard supplier: ");
			orchardName = scanner.next();
		}
		return true;
	}
	
	/**
	 * this method is to output the item that is formatted 
	 */
	@Override
	public void outputItem(Formatter writer) {
		writer.format("f\n");
		super.outputItem(writer);
		writer.format("%s\n" , this.orchardName );
	}
	

}
