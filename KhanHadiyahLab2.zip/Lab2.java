import java.util.Random;

public class Lab2 {

	public static void main(String[] args) {
		Lab2 thisLab = new Lab2();
		int counter = 97; // ASCII lowercase a.
		Random myrand = new Random(); // For random number generation.
		int rows = myrand.nextInt(5) + 1;
		char[][] myArray = new char[rows][]; // Creation of random-height 2D array.
		for (int i = 0; i < rows; i++) // This loop creates rows of random length.
		{
			int cols = myrand.nextInt(6); // Value from 0 to 6.
			myArray[i] = new char[cols]; // NB: There may be 0-width rows!
			for (int j = 0; j < cols; j++) {
				myArray[i][j] = (char) counter++; // Fill array with chars.
			}
		}
		thisLab.printSquare(myArray); // Call to your method

// create method printSquare that accepts a 2 dementional array-chars
		// go through array- print contents of each cell in square

	}

	void printBox(char[][] myArray, int rows, String left, String right) {

		for (int i = 0; i < myArray[rows].length; i++) { // for the left side of the box pattern

			System.out.print(left);

		}

		if (myArray[rows].length != 0) { // for the left side of the box pattern

			System.out.println(right);

		}

	}

	private void printSquare(char[][] myArray) {

		for (int rows = 0; rows < myArray.length; rows++) { // loop for the 2 demensional array- rows (1st part)

			printBox(myArray, rows, "+-----", "+");
			printBox(myArray, rows, "|     ", "|"); // top of the box 

			for (int cols = 0; cols < myArray[rows].length; cols++) { // loop for the 2 demensional array- collums (2nd
																		// part)

				System.out.print("|  " + myArray[rows][cols] + "  "); // middle of the box 

			}

			if (myArray[rows].length != 0) {

				System.out.println("|"); // if the collums are 0 = dont print

			}

			printBox(myArray, rows, "|     ", "|");
			printBox(myArray, rows, "+-----", "+");// bottom part of the box 

		}

	}

}
