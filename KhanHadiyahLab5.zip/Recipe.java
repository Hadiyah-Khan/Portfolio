import java.util.Scanner;

/**
 * @author Hadiy
 *
 */
public class Recipe {

	
	
	/**
	 * float variable for yeast 
	 */
	float yeast;
	/**
	 * float variable for flour 
	 */
	float flour; 
	/**
	 * float variable for eggs
	 */
	float eggs;
	/**
	 * Float variable for butter 
	 */
	float butter;
	/**
	 * Float variable for sugar 
	 */
	float sugar;
	/**
	 * String variable for bread 
	 */
	String bread;
	/**
	 * int variable for quantity
	 */
	int quantity;
	/**
	 * int variable for numberOfBread 
	 */
	int numberOfBread;
	
	/**
	 * @return quantity 
	 */
	public int getQuantity() {
		return quantity;
	}
	/**
	 * @param quantity means means the quantity of bread the user wants 
	 * 
	 */
	public void setQuantity(int quantity) {
		this.quantity = quantity;
		
		if (this.quantity <0) { // if quantity is less then 0 then equal to 0
			this.quantity = 0;
		}
		
	}
	/**
	 * @return numebrOfBread
	 */
	public int getNumberOfBread() {
		return numberOfBread;
	}
	/**
	 * @param numberOfBread means the number of the bread requested that corresponds with the numebr in the arrayList + 1
	 */
	public void setNumberOfBread(int numberOfBread) {
		this.numberOfBread = numberOfBread;
	}
	/**
	 * @return yeast 
	 */
	public float getYeast() {
		return yeast;
	}
	/**
	 * @param yeast is a float 
	 */
	public void setYeast(float yeast) {
		this.yeast = yeast;
	}
	/**
	 * @return flour 
	 */
	public float getFlour() {
		return flour;
	}
	/**
	 * @param flour is a float 
	 */
	public void setFlour(float flour) {
		this.flour = flour;
	}
	/**
	 * @return eggs 
	 */
	public float getEggs() {
		return eggs;
	}
	/**
	 * @param eggs is a float 
	 */
	public void setEggs(float eggs) {
		this.eggs = eggs;
	}
	/**
	 * @return butter 
	 */
	public float getButter() {
		return butter;
	}
	/**
	 * @param butter is a float 
	 */
	public void setButter(float butter) {
		this.butter = butter;
	}
	/**
	 * @return bread 
	 */
	public String getBread() {
		return bread;
	}
	/**
	 * @param bread is string 
	 */
	public void setBread(String bread) {
		this.bread = bread;
	}
	/**
	 * @return sugar 
	 */
	public float getSugar() {
		return sugar;
	}
	/**
	 * @param sugar is a float 
	 */
	public void setSugar(float sugar) {
		this.sugar = sugar;
	}

 


	

	



}
