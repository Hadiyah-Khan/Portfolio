import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * @author Hadiy
 *
 */
public class lab5 {
	

	@SuppressWarnings("javadoc")
	public static void main(String[] args) {

	Scanner input = new Scanner(System.in);
	RecipeManager RM = new RecipeManager();

	 
	
	final int CHOICE_1 = 1;
	final int CHOICE_2 = 2;
	final int CHOICE_3 = 3;
	final int CHOICE_4 = 4;
	final int CHOICE_0 = 0;
	int choice;
	
	boolean error = false ; 
	
	do {
		
			
			error = false;
			try { 
				do {
					
				
				System.out.println("--------------------------------meneu--------------------------");
				System.out.println( CHOICE_1 + " Show available recipes");
				System.out.println(CHOICE_2 + " Create Shopping List");
				System.out.println( CHOICE_3 +" Print Shopping List");
				System.out.println(CHOICE_4 +" Quit Program");
				System.out.println( CHOICE_0 + " to reprint this menu");
				System.out.println("enter intput: ");
				choice = input.nextInt();
			
				

				switch (choice) {
				case CHOICE_1 :
					RM.breadNames();
					break;
					
				case CHOICE_2:
					RM.orderBread(0,0);
				break;
				case CHOICE_3 :
					RM.shoppingList();
					break;
				case CHOICE_4 :
					System.out.println("Program will shutdown");
					break;
				case CHOICE_0 :
					System.out.println("--------------------------------meneu--------------------------");
					System.out.println( CHOICE_1 + " Show available recipes");
					System.out.println(CHOICE_2 + " Create Shopping List");
					System.out.println( CHOICE_3 +" Print Shopping List");
					System.out.println(CHOICE_4 +" Quit Program");
					System.out.println( CHOICE_0 + " to reprint this menu");
					System.out.println("enter intput: ");
					choice = input.nextInt();
					break;
				default:
					System.out.println("invalid input, try again: valid input: [1,2,3,4,0]  "); 
					
					
				}
				
				}while (choice != 4);
				
			}catch ( InputMismatchException e) {
					 System.out.println(" Please input valid ineteger number: (1,2,3,4,0) ");
					 error = true;
					 input.nextLine();
					 
			}
			
		
		
		
		
		
	} while (error);
	
	 
	
	
	
	

		
		
		
	}
	
	
	
	



}
