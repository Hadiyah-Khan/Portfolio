import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * @author Hadiy
 *this class manages all the recipes. 
 *it has methods for listing the breads, for ordering the reads and for the shopping list
 */
public class RecipeManager extends RecipeTemplate {
	/**
	 * scanner object called input for user input 
	 */
	Scanner input = new Scanner(System.in);
	/**
	 * an object of the class recipe to access the getters and setters. 
	 */
	Recipe recipe = new Recipe();
	/**
	 * an array called recipes that contains length of the array names from the abstract class 
	 */
	int recipes [] = new int [NUMRECIPES + 1];

	 
	
	
	/**
	 * a String arrayList called breads  
	 */
	ArrayList<String> breads = new ArrayList<String>();
	
	
	
	/**
	 * a method that adds the names of the breads into the arrayList with the number list beside them and then prints them vertically 
	 */
	public void breadNames() {
		

	for (int i = 0 ; i < super.NUMRECIPES ; i++ ) {
		
		breads.add( "#" + (i + 1) +". " + super.names[i]  ); 
		
		
	} 
		
//print out bread names with number vertically
	for ( String i : breads ) {
		 System.out.println(i);
		 
		
		 }
	 //System.out.println(breads.get(6));
	}
	
	
	
	/* A method to "order" a number of a type of bread. It should accept two 
        parameters: the bread number (which corresponds to its index in your array or 
        arraylist), and a quantity. You can pass the quantity to the specific recipe if you 
        wish, or you can keep track of the quantity data directly in this class. That's up to  you
        */
	
	/**
	 * @param numberOfBread refers to the number that is input by the user that corresponds with the number of the bread requested
	 * @param quantity refers to the quantity of breads requested 
	 */
	public void orderBread( int numberOfBread , int quantity) {
		
		boolean error = false ; 
		
		do {
			error = false;
			
			try {
				System.out.println("which bread would you like ? : ");
				numberOfBread = input.nextInt();
				while (numberOfBread <= 0 || numberOfBread > NUMRECIPES  ) {
					System.out.println("please only enter numbers. Valid inputs are numbers 0-7 : ");  // if number is less then or equal to 0 or greater than 7, print out error message 
					numberOfBread = input.nextInt();
					
				}
				System.out.println("how much of this bread would you like? : "); // quantity of bread 
				quantity = input.nextInt();
				
			
		
				
					if(recipes[numberOfBread] == 0 ) {
					recipe.setQuantity(quantity); // sets quantity 
					recipes[numberOfBread]=recipe.getQuantity(); //  when 0 , then use previous quantity
				}else if (recipes[numberOfBread] != 0){
					recipe.setQuantity(recipe.getQuantity()+quantity); // add the setQuanittiy and previous quantity 
					recipes[numberOfBread]=recipe.getQuantity();
				}
				
				if (recipes[numberOfBread] != 0) {
					recipe.setNumberOfBread(numberOfBread);
				}
				
				

				
				
				
				
				
			}catch ( InputMismatchException e) {
				 System.out.println(" Please input valid ineteger number: ");
				 error = true;
				 input.nextLine();
			}
			
		} while (error);
		
		
		
	}
	 /**
	 * a method to print the size of the array 
	 */
	public void recipeSize() {
		 
		 System.out.println(breads.size()); // prints the size of the arraylist contianing all the breads
	 }
	
	
	 /**
	 * 
	 * this method prints the quantity with the breads that are selected as well as lists the total amount of ingredients that will be needed to make the breads selectected 
	 * and also an option to convert the measurements into imperial units upon request 
	 * 
	 */
	@SuppressWarnings("unused")
	public void shoppingList() {
		 /**
		  * If no given bread has been requested, do not show that bread (otherwise show it)
          * Accumulate a running total of all the ingredients each bread needs, modified by the quantity of that bread (three brioches will need three  
          * times the butter, for instance).
          * Display ONLY ingredients that are non-zero. So, if no bread needs eggs,  do not display "0 eggs"
		 */
		
		
		 float totalFLour = 0; // initialize total ingredients to 0 at first
		 float totalYeast = 0;
		 float totalSugar = 0;
		 float totalEggs = 0;
		 float totalButter = 0;

	
		 
		 if  (recipe.getNumberOfBread() == 0) {
			 System.out.println("shopping list is empty :( "); // if no breads selected, print this message 
		 }

			 while ( recipe.getNumberOfBread()!= 0) {
					
					
					if ( recipe.getNumberOfBread()== 1) {
						System.out.println( recipe.getQuantity() + " " + breads.get(0) + " loaf/loaves"); // print out the quantity and name of bread selected 
						
						recipe.setFlour(flour[0]); // sets the ingredient values from the arrays in the abstract class for the specif recipies 
						recipe.setYeast(yeast[0]);
						recipe.setSugar(sugar[0]);
						recipe.setEggs(eggs[0]);
						recipe.setButter(butter[0]);
						float flour = recipe.getFlour();  
						float yeast = recipe.getYeast();
						float sugar = recipe.getSugar();
						float eggs = recipe.getEggs();
						float butter = recipe.getButter();
						
						break;
						
					}
					
					if (recipe.getNumberOfBread() == 2) {
						System.out.println( recipe.getQuantity() + " " + breads.get(1) + " loaf/loaves");
						recipe.setFlour(flour[1]);
						recipe.setYeast(yeast[1]);
						recipe.setSugar(sugar[1]);
						recipe.setEggs(eggs[1]);
						recipe.setButter(butter[1]);
						float flour = recipe.getFlour();
						float yeast = recipe.getYeast();
						float sugar = recipe.getSugar();
						float eggs = recipe.getEggs();
						float butter = recipe.getButter();
						break;
					}
					if (recipe.getNumberOfBread() == 3) {
						System.out.println( recipe.getQuantity() + " " +breads.get(2) + " loaf/loaves");
						recipe.setFlour(flour[2]);
						recipe.setYeast(yeast[2]);
						recipe.setSugar(sugar[2]);
						recipe.setEggs(eggs[2]);
						recipe.setButter(butter[2]);
						float flour = recipe.getFlour();
						float yeast = recipe.getYeast();
						float sugar = recipe.getSugar();
						float eggs = recipe.getEggs();
						float butter = recipe.getButter();
						break;
					}
					if (recipe.getNumberOfBread() == 4) {
						System.out.println( recipe.getQuantity() + " " +breads.get(3) + " loaf/loaves");
						recipe.setFlour(flour[3]);
						recipe.setYeast(yeast[3]);
						recipe.setSugar(sugar[3]);
						recipe.setEggs(eggs[3]);
						recipe.setButter(butter[3]);
						float flour = recipe.getFlour();
						float yeast = recipe.getYeast();
						float sugar = recipe.getSugar();
						float eggs = recipe.getEggs();
						float butter = recipe.getButter();
						break;
					
					}
					if (recipe.getNumberOfBread() == 5) {
						System.out.println( recipe.getQuantity() + " " +breads.get(4) + " loaf/loaves");
						recipe.setFlour(flour[4]);
						recipe.setYeast(yeast[4]);
						recipe.setSugar(sugar[4]);
						recipe.setEggs(eggs[4]);
						recipe.setButter(butter[4]);
						float flour = recipe.getFlour();
						float yeast = recipe.getYeast();
						float sugar = recipe.getSugar();
						float eggs = recipe.getEggs();
						float butter = recipe.getButter();
						break;
					}
					if (recipe.getNumberOfBread() == 6) {
						System.out.println( recipe.getQuantity() + " " +breads.get(5) + " loaf/loaves");
						recipe.setFlour(flour[5]);
						recipe.setYeast(yeast[5]);
						recipe.setSugar(sugar[5]);
						recipe.setEggs(eggs[5]);
						recipe.setButter(butter[5]);
						float flour = recipe.getFlour();
						float yeast = recipe.getYeast();
						float sugar = recipe.getSugar();
						float eggs = recipe.getEggs();
						float butter = recipe.getButter();
						break;
					}
					 if (recipe.getNumberOfBread() == 7) {
						System.out.println( recipe.getQuantity() + " " +breads.get(6) + " loaf/loaves");
						recipe.setFlour(flour[6]);
						recipe.setYeast(yeast[6]);
						recipe.setSugar(sugar[6]);
						recipe.setEggs(eggs[6]);
						recipe.setButter(butter[6]);
						float flour = recipe.getFlour();
						float yeast = recipe.getYeast();
						float sugar = recipe.getSugar();
						float eggs = recipe.getEggs();
						float butter = recipe.getButter();
						break;
					}
				
					
				} 
			
			 
			 totalFLour = recipe.getQuantity() * (totalFLour + recipe.getFlour()); // adds up all the ingredients and then multiplies it by number of loafs selected 
				totalYeast =  recipe.getQuantity() * (totalYeast + recipe.getYeast());
				totalSugar =  recipe.getQuantity() * (totalSugar + recipe.getSugar());
				totalEggs =  recipe.getQuantity() *(totalEggs + recipe.getEggs());
				totalButter =  recipe.getQuantity() *(totalButter + recipe.getButter());

			
			 
			 while ( recipe.getNumberOfBread()!= 0) {
				 System.out.println("You will need a total of : ");
				 
				 if (totalFLour != 0) {
					 System.out.println(Math.round(totalFLour) + " grams of flour ");  // lists the total measurement of each ingredient 
				 
				 }
				 
				 if (totalYeast != 0) {
					 System.out.println(Math.round(totalYeast) + " grams of yeast ");
				 
				 }
				 if (totalSugar != 0) {
					 System.out.println(Math.round(totalSugar) + " grams of sugar ");
					 
				 }
				 if (totalButter != 0) {
					 System.out.println(Math.round(totalButter) + " grams of butter ");
					 
				 }
				 if (totalEggs != 0) {
					 System.out.println(Math.round(totalEggs) + " egg(s) ");
					
				 }
				 
				 
				 System.out.println("would you like to convert to imperial measurments? enter 1 for yes, 2 for no "); // bonus imperial conversion 
				 int choice = input.nextInt();
				 
				 if (choice == 1) {
					 System.out.println(" -------------------imperial measuremnts ------------------");
					 
					 if (totalFLour != 0) {
						 System.out.println(Math.round((totalFLour) / 125)  + " cups of flour  "); 
					 
					 }
					 
					 if (totalYeast != 0) {
						 System.out.println(Math.round((totalYeast) / 3.13) + " teaspoons  of yeast ");
					 
					 }
					 if (totalSugar != 0) {
						 System.out.println(Math.round((totalSugar) / 12.5 ) + " tablespoons  of sugar ");
						 
					 }
					 if (totalButter != 0) {
						 System.out.println(Math.round((totalButter) / 	0.002205) + "  pounds  of butter ");
						 
					 }
					 if (totalEggs != 0) {
						 System.out.println(Math.round(totalEggs) + " egg(s) ");
						
					 } 
					 
					 
				 }
				 else if (choice == 2 ) {
					 System.out.println("----------------------back to main menue----------------------"); // if 2 is selected, go back to main menu 
				 }else {
					 System.out.println("please enter valid input. (1 for yes || 2 for no) "); // if anything other than 1 or 2 is entered, error message printed and try again.
					 choice = input.nextInt();
				 }
				 
				 break;
				 
				 
				 
			 }
			 	 
			 
		 }
	
		 	 
		 
	 }
	 
	
	
		


