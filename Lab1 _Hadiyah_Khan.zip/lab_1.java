import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * CET - CS Academic Level 3
 * This class contains the dynamically allocated array and it's processing
 * Student Name: hadiyah Khan
 * Student Number:  041049366
 * Course: CST8130 - Data Structures
 * @author/Professor: James Mwangi PhD. 
 * 
  */
public class lab_1{

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		Numbers nm = null;
		Scanner keyboard = null;
		int size;
				
		final int CHOICE_1 = 1;
		final int CHOICE_2 = 2;
		final int CHOICE_3 = 3;
		final int CHOICE_4 = 4;
		final int CHOICE_5 = 5;
		final int CHOICE_6 = 6;
		int choice;
		boolean error = false ; 
		
		do {
			
			error = false ;
			
			try {
				do {
					

					 
					System.out.println("--------------------------------meneu--------------------------");
					System.out.println( CHOICE_1 + ": Initialize a default array");
					System.out.println(CHOICE_2 + ": To specify the max size of the array");
					System.out.println( CHOICE_3 +": Add value to the array");
					System.out.println(CHOICE_4 +": Display values in the array");
					System.out.println( CHOICE_5 + "Display average of the values, minimum value, maximum value, max mod min");
					System.out.println(CHOICE_6 +": To Exit");
					System.out.println("enter intput: ");
					choice = input.nextInt();
				
				

					switch (choice) {
					case CHOICE_1 :
						nm = new Numbers();
						break;
						
					case CHOICE_2:
						
						try {
							
							System.out.println("entre new size of array: ");
							size = input.nextInt();
							nm = new Numbers(size);
						}catch (InputMismatchException e) {
							System.out.println("please enter a valid integer vlaue");
						} 
						//catch ( ArrayIndexOutOfBoundsException e) {
						//	System.out.println("array is out of bounds");
						//}
						
						
					break;
					case CHOICE_3 :
						
						nm.addValue(keyboard);
						break;
					case CHOICE_4 :
						try {
						System.out.println(nm.toString());
						} catch (NullPointerException e) {
							System.out.println(" array not initialized ");
						}
							
						break;
					case CHOICE_5 :
						nm.calcAverage();nm.findMinMax();nm.getfactorialMax();
						
						
					
						break;
					case CHOICE_6 :
						System.out.println("Program will shutdown");
						break;
					default:
						System.out.println("invalid input, try again: valid input: [1,2,3,4,5,6]  "); 
						
						
					}
				
					
					}while (choice != 6);
				
			}catch ( InputMismatchException e) {
				 System.out.println(" Please input valid ineteger number: (1,2,3,4,5,6) ");
				 error = true;
				 input.nextLine();
			}
		}while (error);
	}
	
	
	

}
