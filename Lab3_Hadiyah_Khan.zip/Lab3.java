
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * CET - CS Academic Level 3
 * This class contains the menue for lab3
 * Student Name: hadiyah Khan
 * Student Number:  041049366
 * Course: CST8130 - Data Structures
 * @author/Professor: James Mwangi PhD. 
 * 
  */
public class Lab3 {



	/**
	 * @param args
	 */
	
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*
		 * new object of scanner called input
		 */
		Scanner input = new Scanner(System.in);
		/*
		 * long variable for system.nanoTime called nano_StartTime
		 */
		long  nano_startTime= System.nanoTime();
		/*
		 * long variable for system.currentTimeMillis called millis_startTime
		 */
		long millis_startTime = System.currentTimeMillis();
		/*
		 *  long variable for system.nanoTime called nano_endTime
		 */
		long nano_endTime = System.nanoTime();
		/*
		 * long variable for system.currentTimeMillis called millis_endTime
		 */
		long millis_endTime = System.currentTimeMillis();
		/*
		 * new object of the class search called s
		 */
		BinaryLinearSearch s = new BinaryLinearSearch();
		/*
		 *int variable that represents the key number that the user wants to be searched for in the array
		 * 
		 */
		int key;
		int index = 0;
		int low = 0;
		int high = 0;
		int x= 0;
		
		/*
		 * the numbered choices to be used for in the switch case in the array 
		 */
		final int CHOICE_1 = 1;
		final int CHOICE_2 = 2;
		final int CHOICE_3 = 3;
		final int CHOICE_4 = 4;
		/*
		 * int variable that will be used in in the user input
		 */
		int choice;
		/*
		 * boolean value for error 
		 */
		boolean error = false ; 
		
		do {
			
			error = false ;
			
			try {
				do {
					

					 
					System.out.println("--------------------------------meneu--------------------------");
					System.out.println( CHOICE_1 + ": Initialize and populate an array of 32 random integers.");
					System.out.println(CHOICE_2 + ": Perform a recursive binary and linear search");
					System.out.println( CHOICE_3 +": Perform iterative binary and linear search.");
					System.out.println(CHOICE_4 +": Exit");
					
					System.out.println("enter intput: ");
					choice = input.nextInt();
				
				
					/*
					 * prints out the sorted and unsorted array 
					 */
					switch (choice) {
					case CHOICE_1 :
						s.generateRandomInts(index);
						
						break;
					/*
					 * enter integer value and print out the recursive binary and linear search as well as the time it took to perform each sort 
					 */
					case CHOICE_2:
						try { 
							System.out.println(" please enter integer vlaue to search:  ");
							key = input.nextInt();
							
							//Search.recursiveBinarySearch(0, 0, 0);
							//s.search(x);
							BinaryLinearSearch.recursiveBinarySearchOutput(key);
							 System.out.println(" ");
							 
							
							 BinaryLinearSearch.recursiveLinearSearchOutput(key, index);
							
							
						}catch (InputMismatchException e) {
							System.out.println(" please enter integer numbers: ");
						}
						
					break;
					
					/*
					 *enter integer value and print out the iterative binary and linear search as well as the time it took to perform each sort 
					 *
					 */
					case CHOICE_3 :
						try { 
							System.out.println(" please enter integer vlaue to search:  ");
							key = input.nextInt();
							
						     s.iteraticBinarySearch(key);  
						     
						  System.out.println(" ");
						  
							s.iterativeLinearSearch(key); 
							
						
						} catch (InputMismatchException e) {
							System.out.println(" please enter integer numbers: ");
						}
						
						
						break;
						/*
						 * exit program
						 */
					case CHOICE_4 :
					
						
						System.out.println("exiting");
						System.out.println(".");
						System.out.println(".");
						System.out.println(".");
						System.out.println(".");
						System.out.println(".");
						System.out.println(".");
						
						
						break;
						/*
						 * the default error for the wrong input in numbers
						 */
					default:
						System.out.println("invalid input valid integers, try again: valid input: [1,2,3,4]  "); 
						
						
					}
				
					
					}while (choice != 4);
				
			}catch ( InputMismatchException e ) {
				// the error for the wrong input in letters
				 System.out.println(" Please input valid integers, try again: valid ineteger number: (1,2,3,4) ");
				 error = true;
				 input.nextLine();
			}
		}while (error);
		
		// close the scanner
		input.close();
	}
	

	
	

}

