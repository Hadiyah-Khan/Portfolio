
/**
 * CET - CS Academic Level 3
 * This class contains the methods for lab3
 * Student Name: hadiyah Khan
 * Student Number:  041049366
 * Course: CST8130 - Data Structures
 * @author/Professor: James Mwangi PhD. 
 * 
  */

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;



public class BinaryLinearSearch {

	/**
	 * int variable for index of key
	 */
	private static int result;
	/**
	 * an array that contains 32 elements
	 */
	private static int[] randNum = new int[32];
	/**
	 * object of random called rand
	 */
	private static Random rand = new Random();
	/**
	 * SENTINEL vlaue for -1 
	 */
	private static final int SENTINEL = -1;
/**
 * an object of scanner called input
 */
	static Scanner input = new Scanner(System.in);
	/**
	 * an int variable mid that stands for stores the vlaue for the middle of the array 
	 */
	private static int mid;
/**
 * the start of the array 
 */
	private static int start = 0;
	/**
	 * the end of the array 
	 */
	private static int end;

	

	
	
	
	
	
	/**
	 * prit out a sorted and unsorted array of 32 numbers form  the range of 0 t0 100
	 * @param key number user is looking for 
	 */
	public static void generateRandomInts( int index ) {

		
		   for (int i = 11; i < 100; i++) { // an array that is from 11 to 99 
		        if (index == 32) {
		            break;
		        }
		        randNum[index] = i;
		        index++;
		   }

		// print unsorted array
		System.out.println("Unsorted Array : " + Arrays.toString(randNum)); // unsorted 

		// sort the array and print the array
		Arrays.sort(randNum);
		System.out.println("Sorted Array: " + Arrays.toString(randNum)); // sorted 

	}

	/**
	 * this method uses iterative/looping constructs to search for a number from a
	 * random list of numbers in an array - it is a binary search
	 */
	public void iteraticBinarySearch(int key) {

		long startTime = System.nanoTime();
		result = BinaryLinearSearch.remainingElements(key);   // calls remianing elements whihc calucaltes the remainign elements for iteriatic binary search 
		long endTime = System.nanoTime();
		if (result == SENTINEL) {  // if reuslt equals setinal that means key is not found 
			System.out.println("Number was not found");
		} else {
			System.out.println("number " + key + " found at index: " + result + " : Iterative  Binary Search ");
			searchTime(startTime, endTime);
		}

	}

	
	
	

	/**
	 * his method uses recursion to search for a number from a random list of
	 * numbers from an array - it is a binary search
	 * @param randNum is the array 
	 * @param left left side of arrayt 
	 * @param right right side of array 
	 * @param key number user is looking for 
	 * @return recursiveBinarySearch method because this is a recurize search 
	 */
	public static int recursiveBinarySearch( int[] randNum, int left, int right, int key ) {
		for(int i = left; i<=right; i++) {
			System.out.print(randNum[i] + " ");
		}
		System.out.println();
		 if (left > right) {						// if left is greater then right return sentinal 
		        return -1;
		    }
		    mid = (left+right) / 2;
		    
		    if (randNum[mid] == key) {
		        return mid;
		    } else if (randNum[mid] < key) {
		    	left = mid+1;  // print out the left side of the array 
//		    	System.out.println(Arrays.toString(Arrays.copyOfRange(randNum, left, right + 1)));
		    } else {
		    	right=mid-1; // print out hte right side of hte array 
//		    	System.out.println(Arrays.toString(Arrays.copyOfRange(randNum, left, right + 1)));
//		        
		    }
		    return recursiveBinarySearch(randNum, left, right, key);
	    
	}
	



	/**
	 * this calclates how how long a search is going ot take 
	 * @param startTim, starting the time of how long hre searhc take s
	 * @param endTime, ending time of how long the search takes
	 */
	public static void searchTime( long startTime, long endTime) {
		
		 try {
	            long duration = endTime - startTime;
	            System.out.println("Time taken in nanoseconds: " + duration + "ns");
	            System.out.println("Time taken in milliseconds: " + duration / 1000000 + "ms");
	        } catch (Exception e) {
	            System.out.println("An error occurred: " + e.getMessage());
	        }
	    }
			
		

		
	
	
	/**
	 * 
	 * @param key is the numebr the user is looking for 
	 */
	public static void recursiveBinarySearchOutput(int key) {
		
		long startTime = System.nanoTime(); // start the time to calclate the search 
        int index = recursiveBinarySearch(randNum, 0, randNum.length - 1, key);
        long endTime = System.nanoTime();
        if (index != -1) {  // if index does not equal setinal return index with key position 
            System.out.println("Number " + key + " found at index " + index + " Recursive Binary Search");
            searchTime(startTime, endTime);  // calls the search time method to see how long the search is gomna take 
        } else {
            System.out.println("Number not found");
        }
	}
		 
	
	

	/**
	 * 
	 * @param key is the value that hte user is searching for 
	 * @return setinal value. they key is not found 
	 */
	public static int remainingElements(int key) {
		
	
		 Arrays.sort(randNum);  // sort thr array 
		 System.out.println(Arrays.toString(randNum)); // prin tout the sorted array 
		 
	        start = 0; // start of htey arrray 
	        end = randNum.length - 1; // end of htey array 
	       
		
			
			
	        while (start <= end) {
	            mid = (start + end) / 2;
	            if (randNum[mid] == key) {
//	            	long startTime = System.nanoTime();
//	            	long endTime = System.nanoTime();
//	                long durationInNano = (endTime - startTime);
//	                long durationInMilli = TimeUnit.NANOSECONDS.toMillis(durationInNano);
//	                System.out.println("Time taken in nano seconds: in method " + durationInNano);
//	                System.out.println("Time taken in milli seconds: in method " + durationInMilli);
	                return mid;
	            } else if (randNum[mid] < key) {
	                start = mid + 1;
	                System.out.println(Arrays.toString(Arrays.copyOfRange(randNum, start, end + 1))); // print out the new array after hte array is changed/ cut in half 
	            } else{
	            	end = mid - 1;
	            	 System.out.println(Arrays.toString(Arrays.copyOfRange(randNum, start, end + 1))); // sam thing again 
	            	
	            }
	        }
	        return SENTINEL;
	    }

	

	/**
	 * 
	 * @param key is the number the user is looking for 
	 */
	public void iterativeLinearSearch(int key) {

		long startTime = System.nanoTime();
		result = BinaryLinearSearch.LinearSearch(key);
		long endTime = System.nanoTime();
		if (result == SENTINEL) {  // if result equals -1 or sentinal. the key is not found 
			System.out.println("Number was not found");
			
		} else {  // if key is found, return the follwoing sentance. 
			System.out.println("number " + key + " found at index: " + result + " : Iterative Linear Search ");
			searchTime(startTime, endTime); // call the method searchTime to get the time it takes to perform the search 
		}

	}
	/**
	 * 
	 * @param key the numebr the user is looking for 
	 * @param index the index value the user is looking for 
	 */
	public static void recursiveLinearSearchOutput(int key, int index) {
		long startTime = System.nanoTime();
		result = BinaryLinearSearch.recursiveLinearSearch(key, index); // reult equals the resulting value from recursiveLinearSearch
		long endTime = System.nanoTime();
		if (result == SENTINEL) {
			System.out.println("Number was not found");
		} else {
			System.out.println("number " + key + " found at index: " + result + " : Recursive Linear Search ");
			searchTime(startTime, endTime);
		}

	}
	
	/**
	 * 
	 *@param key the numebr the user is looking for 
	 * @param index the index value the user is looking for 
	 * @return sentinal value -1, if sentinal returns, the key is not found 
	 */
	public static int recursiveLinearSearch(int key , int index) {
		
		try {
			System.out.print(randNum[index] + " ");
		    if (randNum[index] == key) {
	    	System.out.println();
		        return index; // if array value is equal to key, return the index value, whihc is the number in the array index where key is located 
		    }
		    
		    return recursiveLinearSearch(key, ++index);  
		}catch (NullPointerException e) { 
			System.out.println(" Array needs to be initialised ");
		}catch(ArrayIndexOutOfBoundsException ex) {
			System.out.println("not found");
		}
		
		
		return SENTINEL;
		
	}
		    
	
	
	
	/**
	 * 
	 * @param key
	 * @return
	 */
	public static int LinearSearch(int key) {
		
	        for (int i = 0; i < randNum.length; i++) {
	        	System.out.print(randNum[i] + " ");
	            if (randNum[i] == key) {   // if i in array equals key, return i 
//	            
	            	System.out.println();
	                return i; 
	            }
	        }
	       
	        return SENTINEL;
	    
	}

}

