/*
student name: hadiyah Khan 
professor name: Surbhi Bahri 
due date: 18 september 2022
*/
import java.util.Scanner;

public class lab1Test {

	public static void main(String[] args) {
		Lab1 lab1 = new Lab1();
		Scanner input = new Scanner(System.in);
	
		
		boolean repeat = true; // boolean 
		
	
		do { // do while loop with boolean 

			
			System.out.println("enter height : (-1 to quite)");
		
			if (input.hasNextInt() ) {
				
				int height = input.nextInt();
				if(height % 2==1 && height > 5) { // if the height is an odd number and greater than 5 print the symbol in lab1 with the height entered
					lab1.printPattern(height);
					
				}else if (height == -1) { // if the height entered is -1 then print "exit program" and terminate the program 
				
				
				System.out.println("exit program");
				repeat = false;
				}else {
				System.out.println("not valid: try again"); // if an invalid input is entered (in numbers) print "invalid try again" 
				}
				
				
			}else {
					System.out.println("not valid: try again"); // if an invalid input is entered (in letters) print "invalid try again" 
					}
			input.nextLine();
		}while(repeat);
 
		

	}
}
		

