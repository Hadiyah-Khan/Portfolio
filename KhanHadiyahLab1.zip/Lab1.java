/*
student name: hadiyah Khan 
professor name:Surbhi Bahri 
due date: 18 september 2022
*/
public class Lab1 {
	
	void printPattern(int n) {
		
	
		
		for(int i = 1; i<=n; i++) {
		
			for(int j = 1; j<=n*2; j++) {
				
				if(j<=i*2-1 && i<=(n+1)/2) { // upper left  triangel 
					
					System.out.print("*");
					
				}else if(j>=2*(n-i)+2 && i<=(n+1)/2) { // upper right triagle  
					
					System.out.print("*");
					
				}else if(j<=2*(n-i)+1 && i>=(n+1)/2) { // lower left triangle 
					
					System.out.print("*");
					
				}else if(j>=i*2 && i>=(n+1)/2) { // lower right triangle 
					
					System.out.print("*");
					
				}else {
					
					System.out.print(" "); // empty space 
				}
				
			}
			
			System.out.println();
		
	}
		

}
		
	}