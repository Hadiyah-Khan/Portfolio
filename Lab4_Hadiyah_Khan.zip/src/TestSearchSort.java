import java.security.SecureRandom;
import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.regex.Pattern;


public class TestSearchSort {

private static final int CHOICE_1 = 1;
private static final int CHOICE_2 = 2;
private static final int CHOICE_3 = 3;
private static final int CHOICE_4 = 4;
private static final int CHOICE_5 = 5;

/**
* long variable for system.nanoTime called nano_StartTime
*/
long  nano_startTime= System.nanoTime();
/*
* long variable for system.currentTimeMillis called millis_startTime
*/
long millis_startTime = System.currentTimeMillis();
/*
*  long variable for system.nanoTime called nano_endTime
*/
long nano_endTime = System.nanoTime();
/*
* long variable for system.currentTimeMillis called millis_endTime
*/
long millis_endTime = System.currentTimeMillis();

/**
 * option b for bubble sort 
 */
private static final String OPTION_B = "B";
/**
 * option I for insertion sort
 */
private static final String OPTION_I = "I";
/**
 * option S for selecton sort
 */
private static final String OPTION_S = "S";
/**
 * option M for merge sort
 */
private static final String OPTION_M = "M";
/**
 * option Q for quick sort
 */
private static final String OPTION_Q = "Q";
/**
 * option R to return to previous menu
 */
private static final String OPTION_R = "R";

public static void main (String [] args) {
	/**
	 * objecto of secure random calss called random
	 */
	SecureRandom random = new SecureRandom();
	/**
	 * object of scanner class called input
	 */
	Scanner input = new Scanner (System.in);
	/**
	 * object of searching class called search
	 */
	Searching search = new Searching(args);
	/**
	 * object of sortingAlgorithm class called sort
	 */
	SortingAlgorithms sort = new SortingAlgorithms(args);
	
	
	
	/**
	 * random array of Integers called randomArr initilaised to null
	 */
	Integer[] randomArr = null;
	 int choice = 0;			// int choice initialised to 0
		while (choice != 5) { // run code while choice does not equal 8 - option 8 is for exiting the program
			
			try {
			
				displauMenu(); // method displayMenu is called
				
				choice = input.nextInt();
				
				switch (choice) { // case switch is used to call methods form inventory that correspond to the
				// diffrent choices

				case CHOICE_1:								// print the random array
					
					randomArr = random.ints(1000, 0, 10000).boxed().toArray(Integer[]::new);
					 Integer[] randomArrCopy = Arrays.copyOf(randomArr, randomArr.length);				 // create a copy of the array
					 
					
				        System.out.println("Unsorted array:");					// print out the unsorted array
				        System.out.println(Arrays.toString(randomArr));
				        new SortingAlgorithms<>(randomArrCopy);
					break;
					
				case CHOICE_2:											// do binary recursive search
					do {
						try {
							System.out.println("Please enter an iteger value to search: ");
							int num = input.nextInt();
							if (num  < 0) {
								System.out.println("---------- please enter a positive integer ----------------");
							
							}else {
							long startTime = System.nanoTime(); 					// start time to caluclate how long it takes to perform the search 
							 System.out.println(Arrays.toString(randomArr));
							int index = Searching.binarySearch(randomArr, num, 0, randomArr.length-1);
							
							 if (index == -1) {																			// if index did return -1 then the number was not foudn but if it doesnt then the number is found
						            System.out.println("The number " + num + " was not found in the array.");
						        } else {
						            System.out.println("The number " + num + " was found at index: " + index);
						        }
						
							long endTime = System.nanoTime();							// end time to calculate how logn it takes to perfrom the search
							long duration = endTime - startTime;
							System.out.println("Time taken in nanoseconds: " + duration + "ns");
				            System.out.println("Time taken in milliseconds: " + duration / 1000000 + "ms");
				            break;
							}
						} catch (InputMismatchException e) {						// if user inputs an invalid input, print out an error message
							System.out.println("please enter valid input");
						}catch (NullPointerException e) {
							System.out.println("Array is not initialised");
						}
					} while (true);
					
				
			
					break;
				
				case CHOICE_3:												// do the linear search
					
					do {
						try {
							
							
							long startTime = 0;						// start time to see how long it takes to perform the search 
							System.out.println("Please enter an iteger value to search: ");
							int  num = input.nextInt();
							if (num  < 0) {
								System.out.println("---------- please enter a positive integer ----------------");
							
							}
							else {
								startTime = System.nanoTime(); 
							 System.out.println(Arrays.toString(randomArr));			// print out the array 
							int  index = Searching.linearSearch(randomArr, num, 0);
							
							  if (index == -1) {											// if index returns  then number is not found but if the number is foudn, return message that states where in index the number was found
						            System.out.println("The number " + num + " was not found in the array.");
						        } else {
						            System.out.println("The number " + num + " was found at index: " + index);
						        }
							
							
							long endTime = System.nanoTime();
							long duration = endTime - startTime;
							System.out.println("Time taken in nanoseconds: " + duration + "ns");
				            System.out.println("Time taken in milliseconds: " + duration / 1000000 + "ms");
							break;
							}
						} catch (InputMismatchException e) {
							System.out.println("please enter valid input");
						}catch (NullPointerException e) {
							System.out.println("initialise the array ");
						}
					}while(true);
					break;
					
				case CHOICE_4:												// this goes into menu 2 
					try {
						displayMenu2();
						
						String option = input.next();
						
						switch (option.toUpperCase()) {
						case OPTION_B:												// bubble sort 
							
							System.out.println(Arrays.toString(randomArr));
							sort.bubbleSort(randomArr);
					        System.out.println("Bubble sorted array:");
					        System.out.println(Arrays.toString(randomArr));
					       sort.timeIsertionSort(randomArr);
		
					        break;
					        
						case OPTION_I:													// insertion sort 
							System.out.println(Arrays.toString(randomArr));
							sort.insertionSort(randomArr);
					
						        System.out.println("insertion sorted array:");
						        System.out.println(Arrays.toString(randomArr));
						       sort.timeIsertionSort(randomArr);
						      
						        
						        break;
						        
						case OPTION_S: 													// selection sort 
							
							System.out.println(Arrays.toString(randomArr));
							sort.selectionSort(randomArr);
							
						        System.out.println("Selection sorted array:");
						        System.out.println(Arrays.toString(randomArr));
						       sort.timeSelectionSort(randomArr);
		
						        break;
						case OPTION_M:													// merge sort 
							System.out.println(Arrays.toString(randomArr));
							sort.mergeSort(randomArr, 0, randomArr.length - 1);
							
						        System.out.println("Merge sorted array:");
						       System.out.println(Arrays.toString(randomArr));
						       sort.timeMergeSort(randomArr);
						      
						        break;
						case OPTION_Q:													// quick sort 
							System.out.println(Arrays.toString(randomArr));
							sort.quickSort(randomArr, 0, randomArr.length-1);
							
					        System.out.println("Quick sorted array:");
					        System.out.println(Arrays.toString(randomArr));
					       sort.timeQuickSort(randomArr);
					       
					        break;
						        
						case OPTION_R :											// print menu 1 
							System.out.println("--------------------------------menu--------------------------");
							System.out.println(CHOICE_1 + ": Initialize and populate an array of 1000 random integers");
							System.out.println(CHOICE_2 + ": Perform recursive binary search.");
							System.out.println(CHOICE_3 + ": Perform recursive linear search. )");
							System.out.println(CHOICE_4 + ": Sort the array");
							System.out.println(CHOICE_5 + ": Quit");
							

							System.out.println("enter intput: ");
							choice = input.nextInt();
							
							
							break;	
							
						}
					}catch (InputMismatchException e) {
						System.out.println("please enter valid input");
					}
					
					
					break;
					
				case CHOICE_5: 									//quit the program
					
			System.out.println("EXITING.");
			System.out.println(".");
			System.out.println(".");
			System.out.println(".");
			System.out.println(".");
			System.out.println(".");
			System.out.println(".");
			System.out.println(".");
			System.out.println(".");
					break;
					
				default: 
					System.out.println("please enter valid number option");
				
				
			}
			}catch (InputMismatchException e) {								//error when user inputs incorrect input
				System.out.println(" please enter valid input");
				input.nextLine();
			}
			
		
		}
		
		input.close();
}
/**
 * this is menu 1 
 */
public static void displauMenu() {

	System.out.println("--------------------------------menu--------------------------");
	System.out.println(CHOICE_1 + ": Initialize and populate an array of 1000 random integers");
	System.out.println(CHOICE_2 + ": Perform recursive binary search.");
	System.out.println(CHOICE_3 + ": Perform recursive linear search. )");
	System.out.println(CHOICE_4 + ": Sort the array");
	System.out.println(CHOICE_5 + ": Quit");
	

	System.out.println("enter intput: ");
	
	
	

}
/**
 * this is menu 2 
 */
public static void displayMenu2() {
	
	System.out.println(OPTION_B + ": Bubble Sort  ");
	System.out.println(OPTION_I + ": Insertion Sort");
	System.out.println(OPTION_S + ": Selection Sort");
	System.out.println(OPTION_M + ": Merge Sort");
	System.out.println( OPTION_Q + ": Quick Sort");
	System.out.println(OPTION_R + ": Return to Main Menu");
	System.out.println("enter intput: ");
	 
	
	
}



}
