
public class Searching <T extends Comparable<T>> {
	/**
	 * the array 
	 */
	 private T[] arr;
	 
	 
	 
	 /**
	  * Method initialised the array 
	  * @param arr arr the array to be sorted
	  */
	    public Searching(T[] arr) {
	        this.arr = arr;
	    }

	    /**
	     * Performs a binary search recursively to find a target value in an array of integers.
	     * 
	     * @param T an array of integers to search
	     * @param num the target value to find in the array
	     * @param low the lowest index of the search range
	     * @param high the highest index of the search range
	     * @return the index position of the target value, or -1 if it is not found
	     */
	    public static int binarySearch(Integer[] T, int num, int start, int end) {
	        if (start > end) {
	            return -1;
	        }
	        int mid = (start + end) / 2;
	        if (T[mid].equals(num)) {
	          
	            return mid;
	        } else if (T[mid] > num) {
	            return binarySearch(T, num, start, mid - 1);
	        } else {
	            return binarySearch(T, num, mid + 1, end);
	        }
	    }
	    

		

	    /**
	     * Helper method for performing a binary search on a specified portion of the array.
	     * @param element the element to be found
	     * @param start the starting index of the portion to be searched
	     * @param end the ending index of the portion to be searched
	     * @return the index of the element, or -1 if it is not found
	     */
	    private int binarySearchHelper( Integer[] T ,T element, int start, int end) {
	    	// Check if array is sorted
	        boolean isSorted = true;
	        for (int i = 0; i < T.length - 1; i++) {
	            if (T[i] > T[i + 1]) {
	                isSorted = false;
	                break;
	            }
	        }
	        if (!isSorted) {
	            System.out.println("Error: Array is not sorted!");
	            return -1;
	        }
	        
	    	if (start > end) {
	            return -1;
	        }
	        
	        int mid = (start + end) / 2;
	        
	        if (element.compareTo(arr[mid]) < 0) {
	            return binarySearchHelper( T , element, start, mid - 1);
	        } else if (element.compareTo(arr[mid]) > 0) {
	            return binarySearchHelper( T , element, mid + 1, end);
	        } else {
	            return mid;
	        }
	    }

	    /**
	     * Performs a linear search recursively to find a target value in an array of integers.
	     * 
	     * @param T an array of integers to search
	     * @param num the target value to find in the array
	     * @param index the current index position in the search
	     * @return the index position of the target value, or -1 if it is not found
	     */
	    public static int linearSearch(Integer[] T, int num, int index) {
	        // check if current index is out of bounds
	        if (index >= T.length) {
	            return -1; // number not found
	        }

	        // check if current index contains the desired number
	        if (T[index] == num) {
	            
	            return index;
	        }

	        // recursively search the next index
	        return linearSearch(T, num, index + 1);
	    }

	    /**
	     * Helper method for performing a linear search on the array.
	     * @param element the element to be found
	     * @param index the current index being searched
	     * @return the index of the element, or -1 if it is not found
	     */
	    private int linearSearchHelper(T element, int index) {
	        if (index >= arr.length) {
	            return -1;
	        } else if (arr[index].equals(element)) {
	        	
	            return index;
	        } else {
	            return linearSearchHelper(element, index + 1);
	        }
	    }
	
	
	
	
	
	
	
}
