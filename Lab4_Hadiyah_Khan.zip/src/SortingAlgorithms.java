import java.security.SecureRandom;
import java.util.Arrays;

public class SortingAlgorithms<T extends Comparable<T>> {
	
	/**
	 * the array
	 */
	private T[] arr;

	/**
	 * Constructs a new SortingAlgorithms object with the specified array.
	 * 
	 * @param arr the array to be sorted
	 */
	public SortingAlgorithms(T[] arr) {
		this.arr = arr;
	}

	/**
	 * @param T the array to be sortedthis method performs the bubble sort on the array
	 */
	public void bubbleSort(Integer[] T) { // bubble sort
		
		 if (arr == null) {
		        // handle null array case
		        return;
		    }
		
	    int n = T.length;
	    for (int i = 0; i < n - 1; i++) {
	        for (int j = 0; j < n - i - 1; j++) {
	            if (T[j].compareTo(T[j + 1]) > 0) {
	                Integer temp = T[j];
	                T[j] = T[j + 1];
	                T[j + 1] = temp;
	            }
	        }
	    }
	    // sorted array is now in T
	}

	/**
	 * Sorts the specified array of Integers using Merge Sort algorithm.
	 * 
	 * @param T the array to be sorted
	 */
	public static void mergeSort(Integer[] T) {
		if (T == null || T.length <= 1) {
			return;
		}
		mergeSort(T, 0, T.length - 1);
	}

	/**
	 * Recursively sorts the specified portion of the array using Merge Sort
	 * algorithm.
	 * 
	 * @param T     the array to be sorted
	 * @param left  the starting index of the portion to be sorted
	 * @param right the ending index of the portion to be sorted
	 */
	static void mergeSort(Integer[] T, int left, int right) {
		if (left < right) {
			int mid = (left + right) / 2;
			mergeSort(T, left, mid);
			mergeSort(T, mid + 1, right);
			merge(T, left, mid, right);
		}
	}

	/**
	 * Merges two sorted portions of the array.
	 * 
	 * @param T     the array to be sorted
	 * @param left  the starting index of the first portion
	 * @param mid   the ending index of the first portion and the starting index of
	 *              the second portion
	 * @param right the ending index of the second portion
	 */
	private static void merge(Integer[] T, int left, int mid, int right) {
		int n1 = mid - left + 1;
		int n2 = right - mid;
		Integer[] L = new Integer[n1];
		Integer[] R = new Integer[n2];
		for (int i = 0; i < n1; ++i)
			L[i] = T[left + i];
		for (int j = 0; j < n2; ++j)
			R[j] = T[mid + 1 + j];
		int i = 0, j = 0;
		int k = left;
		while (i < n1 && j < n2) {
			if (L[i] <= R[j]) {
				T[k] = L[i];
				i++;
			} else {
				T[k] = R[j];
				j++;
			}
			k++;
		}
		while (i < n1) {
			T[k] = L[i];
			i++;
			k++;
		}
		while (j < n2) {
			T[k] = R[j];
			j++;
			k++;
		}
	}

	/**
	 * Helper method for performing quick sort on a specified portion of the array.
	 * 
	 * @param T     the array to be sorted
	 * @param start the starting index of the portion to be sorted
	 * @param end   the ending of the protion to be sorted
	 */
	public static void quickSort(Integer[] T, int low, int high) {
		if (low < high) {
			int pivot = partition(T, low, high);
			quickSort(T, low, pivot - 1);
			quickSort(T, pivot + 1, high);
		}
	}

	/**
	 * Sorts an integer array using Quick Sort algorithm.
	 * 
	 * @param arr  the integer array to be sorted
	 * @param low  the starting index of the array to be sorted
	 * @param high the ending index of the array to be sorted
	 * 
	 */
	private static int partition(Integer[] T, int low, int high) {
		int pivot = T[high];
		int i = low - 1;
		for (int j = low; j < high; j++) {
			if (T[j] <= pivot) {
				i++;
				int temp = T[i];
				T[i] = T[j];
				T[j] = temp;
			}
		}
		int temp = T[i + 1];
		T[i + 1] = T[high];
		T[high] = temp;
		return i + 1;
	}

	private void swap(T[] arr, int i, int j) {
		T temp = arr[i];
		arr[i] = arr[j];
		arr[j] = temp;
	}

	/**
	 * this method displays the unsorted array
	 */
	public void displayUnsortedArray() { // print out the unsorted array
		System.out.println("Unsorted Array:");
		for (T element : arr) {
			System.out.print(element + " "); // print out the array
		}
		System.out.println();
	}

	/**
	 * This method implements the Insertion Sort algorithm to sort an array of
	 * Integers in ascending order. The algorithm has a time complexity of O(n^2).
	 *
	 * @param T the array of Integers to be sorted
	 * @return the sorted array of Integers
	 */
	public static void insertionSort(Integer[] T) {
		int n = T.length;
		for (int i = 1; i < n; i++) {
			int key = T[i];
			int j = i - 1;
			while (j >= 0 && T[j] > key) {
				T[j + 1] = T[j];
				j = j - 1;
			}
			T[j + 1] = key;
		}
		return;
	}

	/**
	 * Sorts the given Integer array using Selection Sort algorithm. Complexity:
	 * O(n^2)
	 *
	 * @param T the array of Integers to be sorted
	 */
	public static void selectionSort(Integer[] T) {
		int n = T.length;
		for (int i = 0; i < n - 1; i++) {
			int minIndex = i;
			for (int j = i + 1; j < n; j++) {
				if (T[j] < T[minIndex]) {
					minIndex = j;
				}
			}
			int temp = T[minIndex];
			T[minIndex] = T[i];
			T[i] = temp;
		}
	}

	/**
	 * this method displays the sorted array
	 */
	public void displaySortedArray() { // print out the sorted array
		System.out.println("Sorted Array:");
		for (T element : arr) {
			System.out.print(element + " "); // print out the array
		}
		System.out.println();
	}

	/**
	 * this method times the array
	 * 
	 *  @param T is the array
	 */
	public void timeBubbleSort(Integer[] T) {
		long startTime = System.nanoTime();
		bubbleSort(T);
		long endTime = System.nanoTime();
		long durationNano = endTime - startTime;
		double durationMilli = durationNano / 1000000.0;
		System.out.println("Bubble Sort Time (nanoseconds): " + durationNano);
		System.out.println("Bubble Sort Time (milliseconds): " + durationMilli);
	}
/**
 * thus method calculates how long it takes to perorm selecton sort 
 * 
 * @param T is the array 
 */
	public void timeSelectionSort(Integer[] T) {
		long startTime = System.nanoTime();
		selectionSort(T);
		long endTime = System.nanoTime();
		long durationNano = endTime - startTime;
		double durationMilli = durationNano / 1000000.0;
		System.out.println("Selection Sort Time (nanoseconds): " + durationNano);
		System.out.println("Selection Sort Time (milliseconds): " + durationMilli);
	}
/**
 * this method calcualtes how long its takes to perform merge sort 
 * 
 * @param T is the array 
 */
	public void timeMergeSort(Integer[] T) {
		long startTime = System.nanoTime();
		mergeSort(T, 0, 0);
		long endTime = System.nanoTime();
		long durationNano = endTime - startTime;
		double durationMilli = durationNano / 1000000.0;
		System.out.println("Merge Sort Time (nanoseconds): " + durationNano);
		System.out.println("Merge Sort Time (milliseconds): " + durationMilli);

	}
/**
 * this method caluclated how long it takes to perfrom insertion sort 
 * 
 * @param T is hte array 
 */
	public void timeIsertionSort(Integer[] T) {
		long startTime = System.nanoTime();
		insertionSort(T);
		long endTime = System.nanoTime();
		long durationNano = endTime - startTime;
		double durationMilli = durationNano / 1000000.0;
		System.out.println("Insertion Sort Time (nanoseconds): " + durationNano);
		System.out.println("Insertion Sort Time (milliseconds): " + durationMilli);

	}
/**
 * this method calcualtes how much time it takes to pefrom quick sort 
 * 
 * @param T is the array 
 */
	public void timeQuickSort(Integer[] T) {
		long startTime = System.nanoTime();
		quickSort(T, 0, 0);
		long endTime = System.nanoTime();
		long durationNano = endTime - startTime;
		double durationMilli = durationNano / 1000000.0;
		System.out.println("Quick Sort Time (nanoseconds): " + durationNano);
		System.out.println("Quick Sort Time (milliseconds): " + durationMilli);

	}

	
	

}
