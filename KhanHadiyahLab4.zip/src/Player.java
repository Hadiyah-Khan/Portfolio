/*
student name: Hadiyah Khan 
Student id: 041049366
professor name:Surbhi Bahri 
due date: 9 November 2022
*/
import java.util.Random;
import java.util.ArrayList;

/**
 * this class contains code for players 
 * @author Hadiy
 *
 */
public class Player
{
	/**
	 * create an arrayList to generate a 'hand' of cards for the players to play
	 */
    private ArrayList<Card> hand = new ArrayList<Card>();
    /**
     * the default for name is "Default" 
     */
    private String name = "Default";
    /**
     * score = 0 at the start of the game
     */
    private int score=0;
    /**
     * create a new object of random 
     */
    Random rand = new Random();
    
    
    /**
     * if nameParam - "", name will be "Default" 
     * @param nameParam - name parameter = name
     */
    public Player(String nameParam)
    {
        name = nameParam;
        if (nameParam.equals(""))
        {
            name="Default";
        }
    }
    
    /**
     *  method for adding cards 
     * @param cardParam means card parameter. added cards must be within the card parameters. 
     */
    public void addCard(Card cardParam)
    {
        hand.add(cardParam);
    }
    
    /**
     * method initializes score to get score  
     * @return score- prints out score
     */
    public int getScore()
    {
        return score;
    }
    
    /**
     * method initializes name to get name 
     * @return name - prints out name 
     */
    public String getName()
    {
        return name;
    }
    
    /**
     * method initializes the hand of cards 
     * @return builder - returns the builder (builder creates the hand of cards)
     */
    public String getHand()
    {
        String builder="";
        for (Card c:hand)
        {
            builder+=c.getShortName();
        }
        return builder;
    }
    
    /**
     * method to play a card 
     * @return chosenCard - returns the card chosen by player 
     */
    public Card playCard()
    {
        if (hand.size()==0) 
        {
            System.out.print("Player:  Request made to play a card when hand is empty.");
            return null;
        }
        
        //Play a card at random.
        //Report which card was played.
        int removeCard = rand.nextInt(hand.size());
        Card chosenCard = hand.get(removeCard);
        hand.remove(chosenCard);
        return chosenCard;
    }
    
    /**
     * method for when a hand is won- when a hand is won, the score increases
     * 
     */
    public void handWon()
    {
        score++;
    }
    
    /**
     * method for reseting the game. clear the hand and set score to 0
     */
    public void reset()
    {
        hand.clear();
        //Empty hand arrayList;
        score=0;
    }
}