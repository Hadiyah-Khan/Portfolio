/*
student name: hadiyah Khan 
Student id: 041049366
professor name:Surbhi Bahri 
due date: 9 November 2022
*/
/**
 * this class implements cardTemplate and generates the max number of cards, suits and faces of the playing cards as well as the error for the wrong value of these cards
 * 
 * @author Hadiy
 * 
 */
public class Card implements CardTemplate
{
    /**
     * MAX_CARDS is the max number of cards, which is 52
     */
    int MAX_CARDS = 52;

    /**
     * MAX_SUITS is the max number of suits the cards can have, which is 4
     */
    int MAX_SUITS = 4;
    /**
     * MAX_FACES is the max number of faces the cards can have, which is 13
     */
    int MAX_FACES = 13;
 

 
    /**
     * curSuit is the current suit
     */
    int curSuit;
    /**
     * curRank is the current rank 
     */
    int curRank;
    
    /**
     * this method is to check the value of the rank and suite so that they don't 0 and to print an error if they do.
     * @param rankParam means rank parameter
     * @param suitParam means suite parameter 
     * 
     */
    public Card(int rankParam, int suitParam)
    {
        curSuit=suitParam; // Initialize 
        curRank=rankParam;
        
        if (suitParam<0||suitParam>MAX_SUITS)
        {
            curSuit = 0;
            System.out.println("Error generating card for value "+suitParam+", "+rankParam);
        }
        
        if (rankParam<0||rankParam>MAX_FACES)
        {
            curRank = 0;
            System.out.println("Error generating card for value "+suitParam+", "+rankParam);
        }

    }
 
    //You need to finish off these methods.
   /**
    * creates method to get shortName
    * @return RankShort short version of ranks 
    */
    public String getShortName()
  
    {
        return rankShort[curRank]+suitShort[curSuit]+" ";
    }
    /**
     * creates method for get longName
     * @return implements CardTemplate.getLongName
     */
    public String getLongName()
    {
        return rankLong[curRank]+" of "+suitLong[curSuit];
    }
}