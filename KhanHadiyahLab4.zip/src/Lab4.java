/*
student name: hadiyah Khan 
Student id: 041049366
professor name:Surbhi Bahri 
due date: 9 November 2022
*/
import java.util.Random;
import java.util.Scanner;
import java.util.ArrayList;

/**
 * this class has the methods that contain code for starting the game and ending the game, menu and dealing cards
 * @author Hadiy
 *
 */
public class Lab4
{
    /**
     * the max amount of players is 4
     */
    final int MAX_PLAYERS = 4;
    
    /**
     * 
     * the cards are placed in an arrayList called deck to create a deck of cards
     */
    ArrayList<Card> deck = new ArrayList<Card>();
    /**
     * the players are placed into an arrayList called playerList that contains the max amount of players.
     * 
     */
    Player[] playerList = new Player[MAX_PLAYERS];
    
    /**
     * STARTING = 0 
     */
    public final int STARTING=0;
    /**
     * IN_PROGRESS = 1
     */
    public final int IN_PROGRESS=1;
    /**
     * FINISHED = 2
     */
    public final int FINISHED=2;
    /**
     * status equals STARTING 
     */
    public int status=STARTING;
    /**
     * we start with 0 rounds 
     */
    public int roundnum=0;
    /**
     * current player = 0 
     */
    public int curPlayer = 0;
    /**
     * create a random object with the name rand 
     */
    Random rand = new Random();
    /**
     * create a new scanner object to use scanner for user input
     */
    Scanner keyboard = new Scanner(System.in);
    
    
    /**
     * @param args public main method String argument 
     */
    public static void main(String[] args)
    {
    	
        @SuppressWarnings("unused")
        /**
         * creates a new object of lab4 called l4
         */
		Lab4 l4 = new Lab4();
    }
    
    /**
     *  creates cards, calls methods startGame() and showRound() , has the menue loop and prints the ending statement at the end of the game
     */
    public Lab4()
    {
        for (int iSuit = 0;iSuit<4;iSuit++)
        {
            for (int iRank = 0;iRank<13;iRank++)
            {
                deck.add(new Card(iRank, iSuit));
            }
        }
        //Cards are now created.
        
        startGame();

        
 
        //Menu loop
        boolean quitting=false;
        while(!quitting)
        {
            dealCards();
            quitting = showRound();
            
            //read menu
            //do menu items
        }
        System.out.println("Thanks for playing!\nThis Auto-Cards implementation by Daniel Cormier.");
    }
    
    /**
     * a boolean method for showing what round it is and for continuing or ending the game, picking a winner and showing final scores. 
     * @return true if player chooses 'y' or 'Y' to continue the game
     */
    public boolean showRound()
    {
        int roundNum=1;
        int playerOffset=0;
        String response="";
        

        do
        {
            System.out.println("This is round "+roundNum+".");
            //Show of hands.
            for (int i=0;i<MAX_PLAYERS;i++)
            {
                System.out.println(playerList[i].getName()+"("+playerList[i].getScore()+
                                   " hands won):"+playerList[i].getHand());
            }

            //User bailout chance.
            System.out.println("Enter q to quit, anything else to play out this round: ");
            response = keyboard.nextLine();
            if (response.equals("q")||response.equals("Q")) return true;

            //Players play cards.
            for (int i=0;i<MAX_PLAYERS;i++)
            {
                int curPlayer=(i+playerOffset)%MAX_PLAYERS;
                Card tempCard = playerList[curPlayer].playCard();
                System.out.println(playerList[curPlayer].getName()+" plays "+tempCard.getLongName());
                deck.add(tempCard);
            }

            //Pick a fucking winner.
            playerOffset=rand.nextInt(MAX_PLAYERS);
            System.out.println(playerList[playerOffset].getName()+" wins this hand!\n");
            playerList[playerOffset].handWon();
            roundNum++;

            //Is it game over yet?
        }
        while (roundNum<14);

        System.out.println("Game over!");
        System.out.println("Final scores:");
        int max=0;
        int chosenPlayer=0;
        for (int i=0;i<MAX_PLAYERS;i++)
        {
            System.out.println(playerList[i].getName()+" with "+playerList[i].getScore()+" hands won.");
            if (playerList[i].getScore()>max)
            {
                max=playerList[i].getScore();
                chosenPlayer=i;
            }
        }
        System.out.println(playerList[chosenPlayer].getName()+" has won! (unless they tied)");
        System.out.println("\nAnother game? y to continue: ");

        response = keyboard.nextLine();
        if (response.equals("y")||response.equals("Y")) return false;
        return true;
        
    }
    
    /**
     * method deals the cards 
     */
    public void dealCards()
    {
        //Clear players out.
        for (int i=0;i<MAX_PLAYERS;i++)
        {
            playerList[i].reset();
        }
        
        System.out.println("Dealing cards...");
        int cardSel = 0;
        int deckSize=deck.size();
        for (int i=0;i<deckSize;i++)
        {
            cardSel = rand.nextInt(deck.size());
            playerList[i%MAX_PLAYERS].addCard(deck.get(cardSel));
            deck.remove(cardSel);
        }
    }
    
    
    
    /**
     * method for the start of the game
     */
    public void startGame()
    {
        System.out.println("Welcome to Auto-Cards.");
        System.out.println("Before we start, let's name the four players.");
        
        String name="";
        for (int i=0;i<MAX_PLAYERS;i++)
        {
            do
            {
                System.out.print("Enter player "+(i+1)+"'s name: ");
                name=keyboard.nextLine();
                if (name.length()<3) System.out.println("Names must be at least three characters long.");
            }
            while (name.length()<3);
            playerList[i]=new Player(name);
        }
        
    }
    
    
}